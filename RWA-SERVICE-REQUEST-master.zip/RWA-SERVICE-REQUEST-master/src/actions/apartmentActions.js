import { createAction } from "redux-actions";

export const GET_APARTMENT_INFO = "APARTMENT/GET_APARTMENT_INFO";
export const GET_APARTMENT_INFO_REQUEST =
  "APARTMENT/GET_APARTMENT_INFO_REQUEST";
export const GET_APARTMENT_INFO_FAILURE =
  "APARTMENT/GET_APARTMENT_INFO_FAILURE";
export const GET_APARTMENT_INFO_SUCCESS =
  "APARTMENT/GET_APARTMENT_INFO_SUCCESS";

export const getApartmentInfo = createAction(GET_APARTMENT_INFO);
export const getApartmentInfoRequest = createAction(GET_APARTMENT_INFO_REQUEST);
export const getApartmentInfoFailure = createAction(GET_APARTMENT_INFO_FAILURE);
export const getApartmentInfoSuccess = createAction(GET_APARTMENT_INFO_SUCCESS);
