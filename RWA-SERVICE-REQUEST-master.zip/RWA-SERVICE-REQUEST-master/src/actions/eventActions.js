import { createAction } from "redux-actions";

// state for create event
export const CREATE_EVENT = "EVENT/CREATE_EVENT";
export const CREATE_EVENT_REQUEST = "EVENT/CREATE_EVENT_REQUEST";
export const CREATE_EVENT_FAILURE = "EVENT/CREATE_EVENT_FAILURE";
export const CREATE_EVENT_SUCCESS = "EVENT/CREATE_EVENT_SUCCESS";

export const createEvent = createAction(CREATE_EVENT);
export const createEventRequest = createAction(CREATE_EVENT_REQUEST);
export const createEventFailure = createAction(CREATE_EVENT_FAILURE);
export const createEventSuccess = createAction(CREATE_EVENT_SUCCESS);

// state for update event
export const UPDATE_EVENT = "EVENT/UPDATE_EVENT";
export const UPDATE_EVENT_REQUEST = "EVENT/UPDATE_EVENT_REQUEST";
export const UPDATE_EVENT_FAILURE = "EVENT/UPDATE_EVENT_FAILURE";
export const UPDATE_EVENT_SUCCESS = "EVENT/UPDATE_EVENT_SUCCESS";

export const updateEvent = createAction(UPDATE_EVENT);
export const updateEventRequest = createAction(UPDATE_EVENT_REQUEST);
export const updateEventFailure = createAction(UPDATE_EVENT_FAILURE);
export const updateEventSuccess = createAction(UPDATE_EVENT_SUCCESS);

// State for get event list 
export const GET_EVENTS = "EVENT/GET_EVENTS";
export const GET_EVENTS_REQUEST = "EVENT/GET_EVENTS_REQUEST";
export const GET_EVENTS_SUCCESS = "EVENT/GET_EVENTS_SUCCESS";
export const GET_EVENTS_FAILURE = "EVENT/GET_EVENTS_FAILURE";

export const getEvents = createAction(GET_EVENTS);
export const getEventsRequest = createAction(GET_EVENTS_REQUEST);
export const getEventsSuccess = createAction(GET_EVENTS_SUCCESS);
export const getEventsFailure = createAction(GET_EVENTS_FAILURE);

// State for get single event 
export const GET_SINGLE_EVENT = "EVENT/GET_SINGLE_EVENT";
export const GET_SINGLE_EVENT_REQUEST = "EVENT/GET_SINGLE_EVENT_REQUEST";
export const GET_SINGLE_EVENT_SUCCESS = "EVENT/GET_SINGLE_EVENT_SUCCESS";
export const GET_SINGLE_EVENT_FAILURE = "EVENT/GET_SINGLE_EVENT_FAILURE";

export const getSingleEvent = createAction(GET_SINGLE_EVENT);
export const getSingleEventRequest = createAction(GET_SINGLE_EVENT_REQUEST);
export const getSingleEventFailure = createAction(GET_SINGLE_EVENT_FAILURE);
export const getSingleEventSuccess = createAction(GET_SINGLE_EVENT_SUCCESS);
