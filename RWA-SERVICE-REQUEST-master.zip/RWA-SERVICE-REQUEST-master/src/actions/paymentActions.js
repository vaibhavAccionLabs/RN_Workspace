import { createAction } from "redux-actions";

// state for create payment 
export const CREATE_PAYMENT = "AUTH/CREATE_PAYMENT";
export const CREATE_PAYMENT_REQUEST = "AUTH/CREATE_PAYMENT_REQUEST";
export const CREATE_PAYMENT_FAILURE = "AUTH/CREATE_PAYMENT_FAILURE";
export const CREATE_PAYMENT_SUCCESS = "AUTH/CREATE_PAYMENT_SUCCESS";

export const createPayment = createAction(CREATE_PAYMENT);
export const createPaymentRequest = createAction(CREATE_PAYMENT_REQUEST);
export const createPaymentFailure = createAction(CREATE_PAYMENT_FAILURE);
export const createPaymentSuccess = createAction(CREATE_PAYMENT_SUCCESS);

// state for payment list
export const GET_PAYMENTS_LIST = "AUTH/GET_PAYMENTS_LIST";
export const GET_PAYMENTS_LIST_REQUEST = "AUTH/GET_PAYMENTS_LIST_REQUEST";
export const GET_PAYMENTS_LIST_FAILURE = "AUTH/GET_PAYMENTS_LIST_FAILURE";
export const GET_PAYMENTS_LIST_SUCCESS = "AUTH/GET_PAYMENTS_LIST_SUCCESS";

export const getPaymentsList = createAction(GET_PAYMENTS_LIST);
export const getPaymentsListRequest = createAction(GET_PAYMENTS_LIST_REQUEST);
export const getPaymentsListFailure = createAction(GET_PAYMENTS_LIST_FAILURE);
export const getPaymentsListSuccess = createAction(GET_PAYMENTS_LIST_SUCCESS);

