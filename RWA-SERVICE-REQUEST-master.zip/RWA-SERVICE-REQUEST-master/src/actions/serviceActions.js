import { createAction } from "redux-actions";

export const REFRESH_SERVICE_LISTS = "SERVICE_LIST/REFRESH_SERVICE_LISTS";
export const REFRESH_SERVICE_LISTS_REQUEST =
  "SERVICE_LIST/REFRESH_SERVICE_LISTS_REQUEST";
export const REFRESH_SERVICE_LISTS_SUCCESS =
  "SERVICE_LIST/REFRESH_SERVICE_LISTS_SUCCESS";
export const REFRESH_SERVICE_LISTS_FAILURE =
  "SERVICE_LIST/REFRESH_SERVICE_LISTS_FAILURE";

export const refreshServiceLists = createAction(REFRESH_SERVICE_LISTS);
export const refreshServiceListsRequest = createAction(
  REFRESH_SERVICE_LISTS_REQUEST
);
export const refreshServiceListsSuccess = createAction(
  REFRESH_SERVICE_LISTS_SUCCESS
);
export const refreshServiceListsFailure = createAction(
  REFRESH_SERVICE_LISTS_FAILURE
);

export const LOAD_MORE_SERVICE = "SERVICE_LIST/LOAD_MORE_SERVICE";
export const LOAD_MORE_SERVICE_REQUEST =
  "SERVICE_LIST/LOAD_MORE_SERVICE_REQUEST";
export const LOAD_MORE_SERVICE_SUCCESS =
  "SERVICE_LIST/LOAD_MORE_SERVICE_SUCCESS";
export const LOAD_MORE_SERVICE_FAILURE =
  "SERVICE_LIST/LOAD_MORE_SERVICE_FAILURE";

export const loadMoreService = createAction(LOAD_MORE_SERVICE);
export const loadMoreServiceRequest = createAction(LOAD_MORE_SERVICE_REQUEST);
export const loadMoreServiceSuccess = createAction(LOAD_MORE_SERVICE_SUCCESS);
export const loadMoreServiceFailure = createAction(LOAD_MORE_SERVICE_FAILURE);

export const UPDATE_SERVICE = "SERVICE_LIST/UPDATE_SERVICE";
export const UPDATE_SERVICE_REQUEST = "SERVICE_LIST/UPDATE_SERVICE_REQUEST";
export const UPDATE_SERVICE_SUCCESS = "SERVICE_LIST/UPDATE_SERVICE_SUCCESS";
export const UPDATE_SERVICE_FAILURE = "SERVICE_LIST/UPDATE_SERVICE_FAILURE";

export const updateService = createAction(UPDATE_SERVICE);
export const updateServiceRequest = createAction(UPDATE_SERVICE_REQUEST);
export const updateServiceSuccess = createAction(UPDATE_SERVICE_SUCCESS);
export const updateServiceFailure = createAction(UPDATE_SERVICE_FAILURE);

export const FETCH_SERVICE_CATEGORIES = "SERVICE_LIST/FETCH_SERVICE_CATEGORIES";
export const FETCH_SERVICE_CATEGORIES_REQUEST =
  "SERVICE_LIST/FETCH_SERVICE_CATEGORIES_REQUEST";
export const FETCH_SERVICE_CATEGORIES_SUCCESS =
  "SERVICE_LIST/FETCH_SERVICE_CATEGORIES_SUCCESS";
export const FETCH_SERVICE_CATEGORIES_FAILURE =
  "SERVICE_LIST/FETCH_SERVICE_CATEGORIES_FAILURE";

export const fetchServiceCategories = createAction(FETCH_SERVICE_CATEGORIES);
export const fetchServiceCategoriesRequest = createAction(
  FETCH_SERVICE_CATEGORIES_REQUEST
);
export const fetchServiceCategoriesSuccess = createAction(
  FETCH_SERVICE_CATEGORIES_SUCCESS
);
export const fetchServiceCategoriesFailure = createAction(
  FETCH_SERVICE_CATEGORIES_FAILURE
);

export const CREATE_SERVICE = "SERVICE_LIST/CREATE_SERVICE";
export const CREATE_SERVICE_REQUEST = "SERVICE_LIST/CREATE_SERVICE_REQUEST";
export const CREATE_SERVICE_SUCCESS = "SERVICE_LIST/CREATE_SERVICE_SUCCESS";
export const CREATE_SERVICE_FAILURE = "SERVICE_LIST/CREATE_SERVICE_FAILURE";

export const createService = createAction(CREATE_SERVICE);
export const createServiceRequest = createAction(CREATE_SERVICE_REQUEST);
export const createServiceSuccess = createAction(CREATE_SERVICE_SUCCESS);
export const createServiceFailure = createAction(CREATE_SERVICE_FAILURE);
