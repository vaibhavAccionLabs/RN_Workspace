import { createAction } from "redux-actions";

// state for visitors list 
export const VISITOR_LIST = "VISITOR/VISITOR_LIST";
export const VISITOR_LIST_REQUEST = "VISITOR/VISITOR_LIST_REQUEST";
export const VISITOR_LIST_FAILURE = "VISITOR/VISITOR_LIST_FAILURE";
export const VISITOR_LIST_SUCCESS = "VISITOR/VISITOR_LIST_SUCCESS";

export const visitorList = createAction(VISITOR_LIST);
export const visitorListRequest = createAction(VISITOR_LIST_REQUEST);
export const visitorListFailure = createAction(VISITOR_LIST_FAILURE);
export const visitorListSuccess = createAction(VISITOR_LIST_SUCCESS);

// state for visitor details 
export const VISITOR_DETAILS = "VISITOR/VISITOR_DETAILS";
export const VISITOR_DETAILS_REQUEST = "VISITOR/VISITOR_DETAILS_REQUEST";
export const VISITOR_DETAILS_FAILURE = "VISITOR/VISITOR_DETAILS_FAILURE";
export const VISITOR_DETAILS_SUCCESS = "VISITOR/VISITOR_DETAILS_SUCCESS";

export const visitorDetails = createAction(VISITOR_DETAILS);
export const visitorDetailsRequest = createAction(VISITOR_DETAILS_REQUEST);
export const visitorDetailsFailure = createAction(VISITOR_DETAILS_FAILURE);
export const visitorDetailsSuccess = createAction(VISITOR_DETAILS_SUCCESS);

