import React from "react";
import { connect } from "react-redux";
import { View, Colors, Touchable, Icon, Text, Image, LinearGradient } from "./";
import { StatusBar } from "react-native";
import { NotificationActions } from "../../actions";

class Header extends React.PureComponent {
  componentDidMount() {
    //this.props.getNotifications();
  }
  goBack = () => {
    this.props.navigation.goBack();
  };
  openDrawer = () => {
    //this.props.drawerNavigation.navigate('DrawerToggle');
  };
  openNotification = () => {
    //this.props.drawerNavigation.navigate('Notifications');
  };
  render() {
    console.log("Header props", this.props);
    const { props } = this;
    //const { notifications, notificationRequestStatus } = this.props;

    return (
      <View>
        <View className="f-row bgWhite">
          <StatusBar
            translucent
            backgroundColor="rgba(255,255,255,1.0)"
            animated
            barStyle="dark-content"
          />
          <View className="w-1-1 f-row f-both mt20">
            {props.back ? (
              <Touchable className="pull-left mt20" onPress={this.goBack}>
                <Image
                  className="addIcon"
                  source={require("../images/icons/back_black.png")}
                />              
              </Touchable>
            ) : (
              <Touchable className="pull-left" onPress={this.openDrawer}>
                <Image
                  className="addIcon"
                  source={require("../images/icons/More.png")}
                />
              </Touchable>
            )}
            <Text className="darkGrey title bold m10">{props.title}</Text>
            {props.title === "Dashboard" && (
              <View className="f-row pull-right f-both">
                {/* <Touchable onPress={this.openNotification}>
                    <Icon
                      name={
                        props.isUnread ? 'bell-ring-outline' : 'bell-outline'
                      }
                      size={26}
                      color={Colors.white}
                    />
                  </Touchable>
                  <View className="notification f-both marginLeft20 mb15">
                    <Text className="white bold">
                      {(this.props.notifications &&
                        this.props.notifications.length) ||
                        0}
                    </Text>
                  </View> */}
              </View>
            )}
            {props.title === "Service List" && (
              <Touchable
                className="pull-right"
                onPress={() => this.props.openRequest()}
              >
                <Image
                  className="addIcon"
                  source={require("../images/icons/plus_black.png")}
                />
              </Touchable>
            )}
          </View>
        </View>
        <View className="dividerHead" />
      </View>
    );
  }
}

export default Header;

// function mapStateToProps(state) {
//   const { notifications, notificationRequestStatus } = state.notification;
//   const isUnread = notifications && notifications.find(n => n.newFlag);
//   return {
//     isUnread,
//     notifications,
//     notificationRequestStatus,
//   };
// }

// export default connect(mapStateToProps, { ...NotificationActions })(Header);
