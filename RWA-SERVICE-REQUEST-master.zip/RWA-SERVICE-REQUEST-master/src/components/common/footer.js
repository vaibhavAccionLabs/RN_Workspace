import React from "react";
import { connect } from "react-redux";
import { View, Colors, Touchable, Icon, Text, Image } from "./";
import { AuthActions, NotificationActions, UserActions } from "../../actions";
import { AsyncStorage, Platform } from "react-native";
import Toast from "react-native-root-toast";

class Footer extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      currentRoute: this.props.navigation.state.routeName,
      filterNotification: [],
      flag: null,
      notificationsNewCount: ""
    };
  }

  // componentWillMount() {
  //   this.props.getNotifications();
  // }

  goToHome = () => this.props.navigation.navigate("Dashboard");
  goToProfile = () => this.props.navigation.navigate("Profile");
  goToEvent = () => this.props.navigation.navigate("Event");
  goToNotification = () => this.props.navigation.navigate("Notifications");

  render() {
    const { props } = this;
    // const { user, token, allNotification } = this.props;
    return (
      <View className="footer">
        <View className="footerBottom">
          <View className="w-1-9 f-row f-both space-between m10">
            <View className="ph5">
              <Touchable onPress={this.goToHome}>
                <View className="f-column m20 ">
                  <Image
                    className="mini_thumb "
                    source={require("../images/icons/Property.png")}
                    resizeMode="cover"
                  />
                  <Text className="sm_Font black bold">Home</Text>
                </View>
              </Touchable>
            </View>
            <View className="ph5">
              <Touchable onPress={() => {}}>
                <View className="f-column m20 f-both">
                  <Image
                    className="mini_thumb "
                    source={require("../images/icons/Messenger.png")}
                    resizeMode="cover"
                  />
                  <Text className="sm_Font black bold">Messanger</Text>
                </View>
              </Touchable>
            </View>
            <View className="ph5">
              <Touchable onPress={this.goToProfile}>
                <View className="f-column m20 f-both">
                  <Image
                    className="mini_thumb "
                    source={require("../images/icons/UserName.png")}
                    resizeMode="cover"
                  />
                  <Text className="sm_Font black bold">Profile</Text>
                </View>
              </Touchable>
            </View>
            <View className="ph5">
              <Touchable onPress={this.goToNotification}>
                <View className="f-column m10 f-both">
                  <Image
                    className="mini_thumb "
                    source={require("../images/icons/Notification.png")}
                    resizeMode="cover"
                  />
                  <Text className=" sm_Font black bold">Notification</Text>
                </View>
              </Touchable>
            </View>
            <View className="ph5">
              <Touchable onPress={() => {}}>
                <View className="f-column m10 f-both">
                  <Image
                    className="mini_m_thumb "
                    source={require("../images/icons/More.png")}
                    resizeMode="cover"
                  />
                  <Text className="sm_Font black bold mt5">More</Text>
                </View>
              </Touchable>
            </View>
          </View>
        </View>
      </View>
    );
  }
}

export default Footer;

// function mapStateToProps(state) {
//   const { user } = state.auth;
//   const token = state.auth.authToken;
//   const { notifications, notificationStatus } = state.notifications;
//   const allNotification = notifications && notifications.notifications;
//   return {
//     user,
//     token,
//     allNotification,
//   };
// }

// export default connect(mapStateToProps, {
//   ...AuthActions,
//   ...NotificationActions,
// })(Footer);
