import React from "react";
import Pdf from "react-native-pdf";
import { StyleSheet, Modal } from "react-native";
import { View, Touchable, Image, Colors, Icon, Text } from "./";

export default class PDFExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pdfVisible: false,
      pdfUrl:
        "https://s3.ap-south-1.amazonaws.com/5a585371ed34a3331e9ae3b0/1525434168322.pdf"
    };
  }

  togglePdfViewer = () => {
    this.setState({ pdfVisible: !this.state.pdfVisible });
  };

  render() {
    const source = { uri: this.state.pdfUrl, cache: true };
    // const source = require('./test.pdf');  // ios only
    // const source = {uri:'bundle-assets://test.pdf'};

    // const source = {uri:'file:///sdcard/test.pdf'};
    // const source = {uri:"data:application/pdf;base64,..."};

    return (
      <View style={styles.container}>
        <View className="f-row">
          <Touchable onPress={this.togglePdfViewer}>
            <Image
              className="normal_thumb"
              source={require("../images/icons/pdf-File-View.png")}
            />
          </Touchable>
          {this.state.pdfUrl && (
            <Pdf
              source={source}
              onLoadComplete={(numberOfPages, filePath) => {
                console.log(`number of pages: ${numberOfPages}`);
              }}
              onPageChanged={(page, numberOfPages) => {
                console.log(`current page: ${page}`);
              }}
              onError={error => {
                console.log(error);
              }}
              style={styles.pdf}
            />
          )}
          {this.state.pdfVisible && (
            <Modal
              animationType="slide"
              transparent={false}
              visible={this.state.pdfVisible}
              onRequestClose={() => {
                console.log("Modal has been closed.");
              }}
            >
              <View className="screen">
                <Pdf
                  source={source}
                  onLoadComplete={(numberOfPages, filePath) => {
                    console.log(`number of pages: ${numberOfPages}`);
                  }}
                  onPageChanged={(page, numberOfPages) => {
                    console.log(`current page: ${page}`);
                  }}
                  onError={error => {
                    console.log(error);
                  }}
                  style={styles.container}
                />

                <Touchable
                  className="topRight"
                  onPress={() => {
                    this.setState({ pdfVisible: false });
                  }}
                >
                  <Icon name="close" size={30} color="black" />
                </Touchable>
              </View>
            </Modal>
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  pdf: {
    flex: 1,
    width: 50,
    height: 60
  }
});
