import React from "react";
import { connect } from "react-redux";
import {
  Text,
  View,
  Image,
  Touchable,
  Icon,
  Footer,
  Header,
  BackgroundView,
  LinearGradient,
  BackgroundImage,
  Spinner,
  ScrollView,
  Colors
} from "../common";
import { ApartmentActions, ProjectActions } from "../../actions";
import Toast from "react-native-root-toast";
import { StatusBar } from "react-native";

class Dashboard extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      projectName: "NA",
      projectLocation: "NA",
      activeFlag: "event",
      activeFlagBorderColor: "#3CCDFD",
      activeFlagTextColor: "white"
    };
  }

  componentDidMount() {
    // this.props.getApartmentInfo();
    // if(this.props.projectId){
    //   this.props.fetchProjectDetails(this.props.projectId);
    // }
  }

  gotoPropertyDetails = () => {this.props.navigation.navigate("Property Details")};
  gotoEvents = () => {this.props.navigation.navigate("Event")};
  gotoServiceRequest = () => this.props.navigation.navigate("Service List");
  gotoVisitorsList = () => this.props.navigation.navigate("VisitorList");
  goToPaymentList = () => {this.props.navigation.navigate("PaymentList") };

  renderTab = () => {
    if (this.state.activeFlag === "event") {
      return (
        <View className="f-row bg-transparent mt10  mb20 ">
          <ScrollView horizontal>
            <Touchable onPress={this.gotoEvents}>
              <View style={{padding: 20 }}>
                <BackgroundImage
                  className="view_event"
                  source={require("../images/icons/holi.jpeg")}
                  imageStyle={{ borderRadius: 25 }}
                >
                  <Text className="t-center white bgDarkGrey mt100 p15">Holii</Text>
                </BackgroundImage>
              </View>
            </Touchable>
            <Touchable onPress={this.gotoEvents}>
              <View style={{ padding: 20 }}>
                <BackgroundImage
                  className="view_event"
                  source={require("../images/icons/holi.jpeg")}
                  imageStyle={{ borderRadius: 25 }}
                >
                  <Text className="t-center white bgDarkGrey mt100 p15">Holii</Text>
                </BackgroundImage>
              </View>
            </Touchable>
            <Touchable onPress={this.gotoEvents}>
              <View style={{ padding: 20 }}>
                <BackgroundImage
                  className="view_event"
                  source={require("../images/icons/holi.jpeg")}
                  imageStyle={{ borderRadius: 25 }}
                >
                  <Text className="t-center white bgDarkGrey mt100 p15">Holii</Text>
                </BackgroundImage>
              </View>
            </Touchable>
          </ScrollView>
        </View>
      );
    } else if (this.state.activeFlag === "activity") {
      return (
        <View className="bg-transparent mt10  mb20 space-between">
          <View className="flex f-both p10">
            <Text className="darkGrey bold">Coming soon...</Text>
          </View>
        </View>
      );
    } else if (this.state.activeFlag === "others") {
      return (
        <View className="bg-transparent mt10  mb20 space-between">
          <View className="flex f-both p10">
            <Text className="darkGrey bold">Coming soon...</Text>
          </View>
        </View>
      );
    }
  };

  render() {
    // const {
    //   services,
    //   projects,
    //   projectId,
    //   getApartmentInfoRequest,
    //   fetchDetailsRequestStatus,
    //   fetchDetailsError
    // } = this.props;
    console.log(this.props, "Dashboard");
    // if (projects && projects.length > 0) {
    //   projects.forEach(p => {
    //     const name = p.name;
    //     const location = p.projectDetails.location;
    //     this.setState({ projectName: name, projectLocation: location });
    //   });
    // }
    this.setState({
      projectName: "Narun Srinivas",
      projectLocation: "D3-0408"
    });
    return (
      <View className="flex_1">
        <View className="screen bgWhite">
          <ScrollView>
            <View className="mt20">
              <StatusBar
                translucent
                backgroundColor="rgba(255,255,255,1.0)"
                animated
                barStyle="dark-content"
              />
            </View>
            <View className="f-row bgLgGrey mt5 h50 space-around">
              <Touchable onPress={this.gotoPropertyDetails}>
                <View >
                  <Image
                    className="mini1_thumb"
                    source={require("../images/icons/Property.png")}
                  />
                </View>
              </Touchable>
              <View className="f-column">
                <Text className="boldFont darkGrey">
                  {this.state.projectName}
                </Text>
                <Text className="boldFont darkGrey">
                  {this.state.projectLocation}
                </Text>
              </View>
              <View className="f-column ">
                <Text className="boldFont darkGrey">3 BHK</Text>
                <Text className="boldFont darkGrey">1900 Sft</Text>
              </View>
            </View>
            <View className="dividerHead" />
            <View className="mt20">
              <View className="f-row space-around">
                <Touchable onPress={this.gotoVisitorsList}>
                  <View className="f-both">
                    <Image
                      className="thumb"
                      source={require("../images/icons/User_Icon.png")}
                    />
                    <Text className="darkGrey t-center m5 mb20">
                      Visitor
                    </Text>
                  </View>
                </Touchable>
                <View className="dividerVertrical"></View>
                <Touchable onPress={this.gotoServiceRequest}>
                  <View className="f-both">
                    <Image
                      className="thumb "
                      source={require("../images/icons/Service-Request.png")}
                    />
                    <Text className="darkGrey t-center m5 mb20">
                      Service
                    </Text>
                  </View>
                </Touchable>
                <View className="dividerVertrical"></View>
                <Touchable onPress={this.goToPaymentList}>
                  <View className="f-both">
                    <Image
                      className="thumb"
                      source={require("../images/icons/Payment.png")}
                    />
                    <View className="badge marginTop48 ml35 f-both">
                      <Text className="sm_Font white bold">0</Text>
                    </View>
                    <Text className="darkGrey mt25 t-center m5 mb20">Payment</Text>
                  </View>
                </Touchable>
              </View>
            </View>
            <View className="flex bgWhite ">
              <View className="f-middle  h38 bgLgGrey ">
                <Text className="f-row darkGrey large t-center m5 mb20">
                  Updates
                </Text>
              </View>
              <View className="bg-transparent mt10 space-between">
                <View className="f-row p5">
                  <View className="f-row bgWhite w-1-1 space-between border-bottom-1 border-grey">
                    <View className="mh10 p5 f-both">
                      <Touchable
                        style={{
                          backgroundColor: "transparent",
                          borderBottomWidth: 5,
                          borderBottomColor:
                            this.state.activeFlag === "event"
                              ? this.state.activeFlagBorderColor
                              : "transparent"
                        }}
                        onPress={() => {
                          this.setState({
                            activeFlag: "event"
                          });
                        }}
                      >
                        <View className="f-both">
                          <Text className="darkGrey medium">Events</Text>
                        </View>
                      </Touchable>
                    </View>
                    <View className="mh10 p5 f-both">
                      <Touchable
                        style={{
                          backgroundColor: "transparent",
                          borderBottomWidth: 5,
                          borderBottomColor:
                            this.state.activeFlag === "activity"
                              ? this.state.activeFlagBorderColor
                              : "transparent"
                        }}
                        onPress={() => {
                          this.setState({
                            activeFlag: "activity"
                          });
                        }}
                      >
                        <View className="mh10 f-both p5">
                          <Text className="darkGrey medium">Activities</Text>
                        </View>
                      </Touchable>
                    </View>
                    <View className="mh10 p5  f-both">
                      <Touchable
                        style={{
                          backgroundColor: "transparent",
                          borderBottomWidth: 5,
                          borderBottomColor:
                            this.state.activeFlag === "others"
                              ? this.state.activeFlagBorderColor
                              : "transparent"
                        }}
                        onPress={() => {
                          this.setState({
                            activeFlag: "others"
                          });
                        }}
                      >
                        <View className="f-both">
                          <Text className="darkGrey medium">Others</Text>
                        </View>
                      </Touchable>
                    </View>
                  </View>
                </View>
                <ScrollView>{this.renderTab()}</ScrollView>
              </View>
            </View>
            <View className="f-row f-middle h50  bgLgGrey">
              <View className="dividerDarkGrey mt20"></View>
              <Text className=" darkGrey large m10 ">Near me</Text>
              <View className="dividerDarkGrey mt20"></View>
            </View>
            <View className="flex bgWhite mt10">
              <View className="f-middle  h38 bgLgGrey ">
                <Text className="f-row darkGrey large t-left m5 mb20">
                  Restaurant
                </Text>
              </View>
              <View className="bg-transparent mt10 space-between">
                <View className="f-row bg-transparent mt10  mb20 ">
                  <ScrollView horizontal>
                    <View style={{ borderRadius: 0, padding: 20 }}>
                      <BackgroundImage
                        className="view_event"
                        source={require("../images/icons/food3.jpeg")}
                        imageStyle={{ borderRadius: 25 }}
                      >
                        <Text className="t-center white bgDarkGrey mt100 p15">
                          Pho Montreal
                        </Text>
                      </BackgroundImage>
                    </View>
                    <View style={{ borderRadius: 0, padding: 20 }}>
                      <BackgroundImage
                        className="view_event"
                        source={require("../images/icons/food2.jpg")}
                        imageStyle={{ borderRadius: 25 }}
                      >
                        <Text className="t-center white bgDarkGrey mt100 p15">
                          Rigolati
                        </Text>
                      </BackgroundImage>
                    </View>
                    <View style={{ borderRadius: 0, padding: 20 }}>
                      <BackgroundImage
                        className="view_event"
                        source={require("../images/icons/food3.jpeg")}
                        imageStyle={{ borderRadius: 25 }}
                      >
                        <Text className="t-center white bgDarkGrey mt100 p15">
                          Palam
                        </Text>
                      </BackgroundImage>
                    </View>
                  </ScrollView>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
        <View className="flex01">
          <Footer navigation={this.props.navigation} />
        </View>
      </View>
    );
  }
}

export default Dashboard;

// function mapStateToProps(state) {
//   const { fetchDetailsRequestStatus, fetchDetailsError, projects } = state.project;
//   const { getApartmentInfoRequest } = state.apartment;
//   const projectId = '01'

//   console.log(state, 'auth')
//   return {
//     services: state.service.services || [],
//     projectId,
//     projects,
//     user: state.auth.user,
//     getApartmentInfoRequest,
//     fetchDetailsError,
//     fetchDetailsRequestStatus
//   };
// }

// export default connect(mapStateToProps, { ...ApartmentActions, ...ProjectActions })(Dashboard);
