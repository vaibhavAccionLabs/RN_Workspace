import React from "react";
import idx from "idx";
import { connect } from "react-redux";

import {
  View,
  ScrollView,
  BackgroundImage,
  Image,
  Styles,
  Text,
  Touchable,
  LinearGradient
} from "../common";
import { StatusBar } from "react-native";

const DrawerItem = props => (
  <Touchable
    className="btn-transparent"
    onPress={() => props.goto(props.routeName)}
  >
    <View className="flex f-row f-center w-1-1 p5">
      <Image className="drawerIcon mh10" source={props.icon} />
      <Text className="complementary bold">{props.label}</Text>
    </View>
  </Touchable>
);

class DrawerContent extends React.PureComponent {
  goto = route => {
    this.props.navigation.navigate(route);
  };

  render() {
    const { user } = this.props;
    const { profileImageUrl } = this.props.user;
    return (
      <LinearGradient>
        <ScrollView className="bg-transparent">
          <View className="flex f-both p20 bgWhite mt20">
            <StatusBar
              translucent
              backgroundColor="rgba(0, 0, 0, 0.10)"
              animated
              barStyle="light-content"
            />
            <View className="drawer-avatar">
              {!profileImageUrl ? (
                <Image
                  className="drawer-avatar"
                  source={require("../images/icons/user.png")}
                  resizeMode="contain"
                />
              ) : (
                <Image
                  className="big_thumb"
                  source={{ uri: profileImageUrl }}
                  resizeMode="stretch"
                />
              )}
            </View>
            <Text className="mh10 primary t-center subtitle bold">
              {user.displayName}
            </Text>
          </View>

          <DrawerItem
            routeName="Dashboard"
            goto={this.goto}
            icon={require("../images/icons/dashboard-icon.png")}
            label="Dashboard"
          />
          <DrawerItem
            routeName="Property Details"
            goto={this.goto}
            icon={require("../images/icons/information.png")}
            label="Property Details"
          />
          <DrawerItem
            routeName="Service List"
            goto={this.goto}
            icon={require("../images/icons/information.png")}
            label="Service Request"
          />
          <DrawerItem
            routeName="Notifications"
            goto={this.goto}
            icon={require("../images/icons/user.png")}
            label="Notifications"
          />
          <DrawerItem
            routeName="Profile"
            goto={this.goto}
            icon={require("../images/icons/user.png")}
            label="Profile"
          />
          <DrawerItem
            routeName="Logout"
            goto={this.goto}
            icon={require("../images/icons/logout-icon.png")}
            label="Logout"
          />
        </ScrollView>
      </LinearGradient>
    );
  }
}

function mapStateToProps(state) {
  return {
    user: state.auth.user || {}
  };
}

export default connect(mapStateToProps, {})(DrawerContent);
