import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  Touchable,
  Text,
  SelectInput,
  Spinner,
  FormInput,
  Prompt,
  Footer,
  Header,
  Colors,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import idx from "idx";
import { TextInput } from "react-native";
import { Field, reduxForm, formValueSelector } from "redux-form";

class Event extends React.PureComponent {
  constructor() {
    super();
    this.state = {
      category: ["c1", "c2", "c3", "c4"],
      blocks: ["b1", "b2", "b3", "b4"],
      apartments: ["apartment1", "apartment2", "apartment3", "a4"]
    };
  }

  render() {
    return (
      <KeyboardAvoidingView>
        <View className="flex_1">
          <Header title="Event" back navigation={this.props.navigation} />
          <View className="screen bgWhite">
            {/* <Text className="mt50 darkGrey xx_large t-center">
              Event
            </Text> */}
            <View className="flex">
              <View className="w-1-1">
                <View style={{ borderRadius: 0 }}>
                  <BackgroundImage
                    className="large_Image p20"
                    source={require("../images/icons/holi.jpeg")}
                    resizeMode="contain"
                    imageStyle={{ borderRadius: 0 }}
                  >
                    <Text className="t-left x_large white p15 ">Events</Text>
                    <Text className="t-left white bgGrey mt150 p22">
                      Holi Celebration
                    </Text>
                  </BackgroundImage>
                </View>
              </View>
              <View className="w-1-1 f-row">
                <View style={{ borderRadius: 0 }} className="w-1-2">
                  <BackgroundImage
                    className="h200 ml20 marginTop20"
                    source={require("../images/icons/holi.jpeg")}
                    resizeMode="contain"
                    imageStyle={{ borderRadius: 0 }}
                  />
                </View>
                <View style={{ borderRadius: 0 }} className="w-1-2">
                  <View className="w-1-1">
                    <BackgroundImage
                      className="ml20 wh_70"
                      source={require("../images/icons/holi.jpeg")}
                      resizeMode="contain"
                      imageStyle={{ borderRadius: 0 }}
                    />
                  </View>
                  <View className="w-1-1">
                    <BackgroundImage
                      className="ml20 wh_70"
                      source={require("../images/icons/holi.jpeg")}
                      resizeMode="contain"
                      imageStyle={{ borderRadius: 0 }}
                    />
                  </View>
                </View>
              </View>
              <View className="w-1-9 f-row space-around p3 mh5 ">
                <View>
                  <Image
                    className="mini_m_thumb"
                    source={require("../images/icons/Share.png")}
                  />
                </View>
                <View className="f-row">
                  <Image
                    className="mini_m_thumb"
                    source={require("../images/icons/comment.png")}
                  />
                  <Text className="blue medium">112</Text>
                </View>
                <View className="f-row">
                  <Image
                    className="mini_m_thumb"
                    source={require("../images/icons/Like.png")}
                  />
                  <Text className="blue medium">25</Text>
                </View>
              </View>
            </View>
          </View>
          <View className="flex01">
            <Footer navigation={this.props.navigation} />
          </View>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

Event = reduxForm({
  form: "EventForm",
  destroyOnUnmount: false,
  enableReinitialize: true
})(Event);

const selector = formValueSelector("EventForm");

export default Event;
