import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  Touchable,Dropdowns,
  Text,Header,
  SelectInput,
  Spinner,
  FormInput,
  Prompt,
  Colors,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import idx from "idx";
import { TextInput } from "react-native";
import { Field, reduxForm, formValueSelector } from "redux-form";

class Payment extends React.PureComponent {
  constructor() {
    super();
    this.state = {
      category: [ {
          key: 'c1',
          label: 'c1',
          value: 'c1',
        },
        {
          key: 'c2',
          label: 'c2',
          value: 'c2',
        },
        {
          key: 'c3',
          label: 'c3',
          value: 'c3',
        } ],
       blocks: [ {
          key: 'c1',
          label: 'c1',
          value: 'c1',
        },
        {
          key: 'c2',
          label: 'c2',
          value: 'c2',
        },
        {
          key: 'c3',
          label: 'c3',
          value: 'c3',
        } ], 


       apartments: [ {
          key: 'c1',
          label: 'c1',
          value: 'c1',
        },
        {
          key: 'c2',
          label: 'c2',
          value: 'c2',
        },
        {
          key: 'c3',
          label: 'c3',
          value: 'c3',
        } ]
    };
  }

  render() {
    console.log(this.state.category , '**********')
    return (
      <KeyboardAvoidingView>
        <Header
          back
          navigation={this.props.navigation}
          title="Payment"
        />
        
        <View className="screen bgWhite">
          {// <Text className="mt50 darkGrey xx_large t-center">Payment</Text>
          }
          <View className="flex ">
            <View className="w-1-0 ml10">
              <Field
                component={Dropdowns}
                name="category"
                data={this.state.category}
                light
                label="category"
                placeholder="Select category"
              />
            </View>
            <View className="f-row">
              <View className="w-2-6 ml10">
                <Field
                  component={Dropdowns}
                  name="category"
                  data={this.state.blocks}
                  light
                  label="block"
                  placeholder="Select block"
                />
              </View>
              <View className="w-2-6">
                <Field
                  component={Dropdowns}
                  name="apartment"
                  data={this.state.apartments}
                  light
                  label="apartment"
                  placeholder="Select apartment"
                />
              </View>
            </View>
            <View className="w-1-0 ml20">
              <Field
                name="amount"
                placeholder="Amount"
                component={FormInput}
                cover
              />
            </View>
            <View className="mt50" style={{ borderTopRadius: 10 }}>
              <View className=" f-row p10 bgGrey h40 ">
                <View className="circle" />
                <Text className="white mh20">Credit Card</Text>
              </View>
              <View className=" f-row p10 bgGrey h45 mt5">
                <View className="circle" />
                <Text className="white mh20">Debit Card</Text>
              </View>
              <View className=" f-row p10 bgGrey h45 mt5">
                <View className="circle" />
                <Text className="white mh20">Net Banking</Text>
              </View>
              <View className=" f-row p10 bgGrey h45 mt5">
                <View className="circle" />
                <Text className="white mh20">BHIM UPI</Text>
              </View>
              <View className=" f-row p10 bgGrey h45 mt5">
                <View className="circle" />
                <Text className="white mh20">Other Payment Methods</Text>
              </View>
            </View>
            <View>
              <Touchable
                onPress={() => {}}
                className="btn-primary rounded_15 m15"
              >
                <Text className="white large bold">CONTINUE</Text>
              </Touchable>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

Payment = reduxForm({
  form: "PaymentForm",
  destroyOnUnmount: false,
  enableReinitialize: true
})(Payment);

const selector = formValueSelector("PaymentForm");

export default Payment;
