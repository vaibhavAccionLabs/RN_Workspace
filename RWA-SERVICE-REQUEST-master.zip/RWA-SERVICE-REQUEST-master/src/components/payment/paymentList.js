import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  Touchable,Dropdowns,
  Text,Header,
  SelectInput,
  Spinner,
  FormInput,Footer,
  Prompt,ScrollView,
  Colors,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import idx from "idx";
import { TextInput } from "react-native";
import { Field, reduxForm, formValueSelector } from "redux-form";

class PaymentList extends React.PureComponent {
  constructor() {
    super()
  }

  

  gotoPayment = () => this.props.navigation.navigate('Payment')

  render() {
      let payments = [{
        'type': 'Maintaince for',
        'date': 'apr 2019',
        'lastDate': 'due',
        'amount': '2,500',
        'status': 'pending'
      },
      {
        'type': 'Maintaince for',
        'date': 'may 2019',
        'lastDate': '30 july',
        'amount': '4,500',
        'status': 'pending'
      },
      {
        'type': 'Maintaince for',
        'date': 'june 2019',
        'lastDate': '10 june',
        'amount': '7,500',
        'status': 'completed'
      }]

    console.log(payments[0].type ,'88888')
    return (
      <View className="flex_1">
        <View className="screen bgWhite">
          <Header
            back
            navigation={this.props.navigation}
            title="Payments"
          />
          <View>
          <Touchable className="w-2-5" 
            style={{backgroundColor: "transparent",borderBottomWidth: 2,borderBottomColor:'#3CCDFD'}}
              onPress={() => {}}
            >
            <View className="mr10">
              <Text className="boldFont black">Maintaince</Text>
            </View>
          </Touchable>
          </View>  
          <ScrollView>
          <View className="f-column">
            <View className="f-row mt10 space-between lightBorder">
              <View className="f-row p5  j-start ">
                <View className="f-column">
                  <View className="f-row">
                    <Text className="black">Maintaince for </Text>
                    <Text className="black">july 2019</Text>
                  </View>
                  <View>
                    <Text className="black">12 july</Text>
                  </View>
                </View>
              </View>
              <View className="f-row p5">
                <View className="f-column">
                  <Text className="black t-right">4,500</Text>
                  <Text className="green t-right">Paid</Text>
                </View>
              </View>
            </View>  
            <View className="f-row mt10 space-between lightBorder">
              <View className="f-row p5  j-start ">
                <View className="f-column">
                  <View className="f-row">
                    <Text className="black">Maintaince for </Text>
                    <Text className="black">june 2019</Text>
                  </View>
                  <View>
                    <Text className="black">due</Text>
                  </View>
                </View>
              </View>
              <View className="f-row p5">
                <View className="f-column f-both">
                  <Text className="black t-right">4500</Text>
                  <Touchable className="touchable1" onPress={this.gotoPayment}> 
                    <View >
                      <Text className="red t-right">Pay now</Text>
                    </View>
                  </Touchable>
                </View>
              </View>
            </View>
          </View>  
          </ScrollView>
        </View>
        <View className="flex01">
          <Footer navigation={this.props.navigation} />
        </View>
      </View>
    );
  }
}

export default PaymentList;


// { payments && payments.length > 0 &&
//               payments.map((section,i) => (
//                 <View key={i}>
//                   <View className="f-row p5  j-start ">
//                     <View className="f-column">
//                       <View className="f-row">
//                         <Text className="black">{{section.type }}</Text>
//                         <Text className="black">{{section.date }}</Text>
//                       </View>
//                       <View>
//                         <Text className="black">{{section.lastDate }} </Text>
//                       </View>
//                     </View>
//                   </View>
//                   <View className="f-row p5">
//                     <View className="f-column">
//                       <Text className="black">{{section.amount }} </Text>
//                       {( section.status === 'pending' ) ? 
//                         <Touchable style={{backgroundColor: "transparent",borderWidth: 1,borderColor:'#3CCDFD'}}
//                           onPress={() => {}}
//                           >
//                           <View className="mr10">
//                             <Text className="black">Pay now</Text>
//                           </View>
//                         </Touchable> : null
//                       }
//                       {(section.status === 'completed') ? 
//                         <View>
//                           <Text className="black">Paid</Text>>
//                         </View>
//                          : mull
//                       }
//                     </View>
//                   </View>
//                 </View>
//               )) 
//             }      