import React from "react";
import { connect } from "react-redux";
import {
  View,
  Text,
  Header,
  ScrollView,
  Image,
  BackgroundImage,
  LinearGradient,
  Colors,
  Icon,
  Touchable,
  PDFExample,
  PDFViewer,
  Spinner,
  VideoPlayer
} from "../common";
import moment from "moment";
import idx from "idx";
import { TextInput, Modal, TouchableOpacity, WebView } from "react-native";
import { ProjectActions } from "../../actions";

class PropertyDetails extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      activeFlag: "projects",
      activeFlagBorderColor: "#3CCDFD",
      activeFlagTextColor: "#3CCDFD",
      playerVisible: false,
      imageVisible: false,
      video: "https://www.rmp-streaming.com/media/bbb-360p.mp4",
      image: null,
      projectName: "RWA"
    };
  }

  componentDidMount() {
    // if(this.props.projectId){
    //   this.props.fetchProjectDetails(this.props.projectId);
    // }
  }

  togglePlay = () => {
    this.setState({ playerVisible: !this.state.playerVisible });
  };

  toggleView = () => {
    this.setState({ imageVisible: !this.state.imageVisible });
  };

  // renderTab = () => {
  //   if (this.state.activeFlag === 'flat') {
  //     if (this.props.apartment && this.props.apartment.milestones && this.props.apartment.milestones.length > 0) {
  //       const milestone = this.props.apartment.milestones.map(value => (
  //         <View className="bgLightGrey mt10">
  //           <View className="f-row p5 space-between">
  //             <View className="f-column">
  //               <Text className="black small t-left">
  //                 {moment(value.date).format('DD/MM/YYYY')}
  //                 {'\n'}
  //               </Text>
  //               <Text className="black bold medium t-left">
  //                 {value.activities}
  //               </Text>
  //               <Text className="black small t-left mh20">
  //                 {value.description}
  //               </Text>
  //             </View>
  //             <View className="f-column">
  //               {value.status === 'INPROGRESS'  ? (
  //                 <Image
  //                   className="medium_thumb f-middle"
  //                   source={require('../images/icons/Inprogress.png')}
  //                   resizeMode="contain"
  //                 />
  //                 ) : value.status === 'Completed' ? (
  //                   <Image
  //                     className="medium_thumb f-middle"
  //                     source={require('../images/icons/Completed.png')}
  //                     resizeMode="contain"
  //                   />
  //                 ) : value.status === 'Open' ? (
  //                   <Image
  //                     className="mini1_thumb mb10 f-middle"
  //                     source={require('../images/icons/Inprogress.png')}
  //                     resizeMode="contain"
  //                   />
  //                 ) : null}
  //               <Text className="black small t-left">{value.status}</Text>
  //             </View>
  //             <View className="f-column">
  //               <Image
  //                 className="large_thumb f-middle"
  //                 source={require('../images/icons/Milestone_Blue.png')}
  //                 resizeMode="contain"
  //               />
  //               <Text className="black small marginTop10 t-left">
  //                   Milestone {value.slNo}
  //               </Text>
  //             </View>
  //             <View className="videoView mt10 ml10">
  //               {this.state.video && (
  //               <Touchable onPress={this.togglePlay}>
  //                 <Icon name="play" size={26} />
  //               </Touchable>
  //                 )}
  //               {this.state.playerVisible && (
  //               <Modal
  //                 animationType="slide"
  //                 transparent={false}
  //                 visible={this.state.playerVisible}
  //                 onRequestClose={() => {
  //                   console.log('Modal has been closed.');
  //                 }}
  //               >
  //                 <View className="screen">
  //                   <VideoPlayer
  //                       onCancel={this.togglePlay}
  //                       video={value.videoUrls[0]}
  //                     />
  //                 </View>
  //               </Modal>
  //                 )}
  //             </View>
  //           </View>
  //         </View>
  //       ));
  //       return milestone;
  //     }
  //     else {
  //       return (<View className="f-row f-both mt20">
  //         <Text className="black bold medium t-left">No milestone available</Text>
  //       </View>)
  //     }
  //   }
  //   else if (this.state.activeFlag === 'projects') {
  //     if (this.props.project && this.props.project.milestones && this.props.apartment.milestones.length > 0) {
  //       const milestone = this.props.project.milestones.map(value => (
  //         <View className="bgLightGrey mt10">
  //           <View className="f-row p5 space-between">
  //             <View className="f-column">
  //               <Text className="black small t-left">
  //                 {moment(value.date).format('DD/MM/YYYY')}
  //                 {'\n'}
  //               </Text>
  //               <Text className="black bold medium t-left">
  //                 {value.activities}
  //               </Text>
  //               <Text className="black small t-left mh20">
  //                 {value.description}
  //               </Text>
  //             </View>
  //             <View className="f-column">
  //               {value.status === 'INPROGRESS'  ? (
  //                 <Image
  //                   className="medium_thumb f-middle"
  //                   source={require('../images/icons/Inprogress.png')}
  //                   resizeMode="contain"
  //                 />
  //                 ) : value.status === 'Completed' ? (
  //                   <Image
  //                     className="medium_thumb f-middle"
  //                     source={require('../images/icons/Completed.png')}
  //                     resizeMode="contain"
  //                   />
  //                 ) : value.status === 'Open' ? (
  //                   <Image
  //                     className="mini1_thumb mb10 f-middle"
  //                     source={require('../images/icons/Inprogress.png')}
  //                     resizeMode="contain"
  //                   />
  //                 ) : null}
  //               <Text className="black small t-left">{value.status}</Text>
  //             </View>
  //             <View className="f-column">
  //               <Image
  //                 className="large_thumb f-middle"
  //                 source={require('../images/icons/Milestone_Blue.png')}
  //                 resizeMode="contain"
  //               />
  //               <Text className="black small marginTop10 t-left">
  //                 Milestone {value.slNo}
  //               </Text>
  //             </View>
  //             <View className="videoView mt10 ml10">
  //               {this.state.video && (
  //               <Touchable onPress={this.togglePlay}>
  //                 <Icon name="play" size={26} />
  //               </Touchable>
  //                 )}
  //               {this.state.playerVisible && (
  //               <Modal
  //                 animationType="slide"
  //                 transparent={false}
  //                 visible={this.state.playerVisible}
  //                 onRequestClose={() => {
  //                       console.log('Modal has been closed.');
  //                     }}
  //               >
  //                 <View className="screen">
  //                   <VideoPlayer
  //                         onCancel={this.togglePlay}
  //                         video={value.videoUrls[0]}
  //                       />
  //                 </View>
  //               </Modal>
  //                 )}
  //             </View>
  //           </View>
  //         </View>
  //       ));
  //       return milestone;
  //     }
  //     else {
  //       return (<View className="f-row f-both mt20">
  //         <Text className="black bold medium t-left">No milestone available</Text>
  //       </View>)
  //     }
  //   }
  //   else if (this.state.activeFlag === 'document') {
  //     return (
  //       <View className="f-column ">
  //         <View className=" bgLightGrey mt10 space-between">
  //           <View className="f-row p5 space-between">
  //             <View>
  //               <Text className="black small mt20 t-left">Type</Text>
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small mt20 t-center">Document Name</Text>
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small mt20 t-left">Date</Text>
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small mt20 mr20 t-left">Status</Text>
  //             </View>
  //           </View>

  //           <View className="f-row p5 space-between">
  //             <View className="f-both">
  //               <PDFExample />
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small mt10 t-left">
  //                Purva Seasons & 270 Apartment{'\n'} Users Manual 270418
  //               </Text>
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small t-center">
  //                 {moment(new Date()).format("DD/MM/YYYY")}
  //               </Text>
  //             </View>
  //             <View className="f-both f-column mr5">
  //               <Image
  //                 className="mini1_thumb"
  //                 source={require('../images/icons/View.png')}
  //                 resizeMode="contain"
  //               />
  //               <Text className="black small t-center">View</Text>
  //             </View>
  //           </View>
  //           <View className="f-row p5 space-between">
  //             <View className="f-column">
  //               <PDFViewer />
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small mt10 t-left">
  //                Purva Seasons & 270 Technical & {'\n'}Operation Manual 270418
  //               </Text>
  //             </View>
  //             <View className="f-both">
  //               <Text className="black small t-center">
  //                 {moment(new Date()).format('DD/MM/YYYY')}
  //               </Text>
  //             </View>
  //             <View className="f-both f-column mr5">
  //               <Image
  //                 className="mini1_thumb"
  //                 source={require('../images/icons/NA_view.png')}
  //                 resizeMode="contain"
  //               />
  //               <Text className="black small t-center">NA</Text>
  //             </View>
  //           </View>
  //         </View>
  //       </View>
  //     );
  //   }
  // };

  render() {
    const {
      apartment,
      user,
      project,
      projects,
      fetchDetailsRequestStatus,
      fetchDetailsError
    } = this.props;

    //  if (projects && projects.length > 0) {
    //   projects.forEach(p => {
    //     const name = p.name;
    //     const location = p.projectDetails.location;
    //     this.setState({ projectName: name, projectLocation: location });
    //   });
    // }

    return (
      <View className="screen">
        <Header
          back
          navigation={this.props.navigation}
          title="Property Details"
        />
        <View className="f-row m20 p5 ml10">
          <View className="f-row f-both m20">
            <BackgroundImage
              className="med_thumb m10"
              source={require("../images/icons/User_Icon1.png")}
              resizeMode="cover"
            >
              <Image
                className="med_thumb m10"
                source={require("../images/icons/User_Icon1.png")}
                resizeMode="cover"
              />
            </BackgroundImage>
          </View>
          <View className="pull-right ">
            <Text className="black medium m10">
              Name {"  "} USer 1{"\n"}
              Mobile {"  "} 8419118185 {"\n"}
              Email {"  "} xxx@gmail.com {"\n"}
            </Text>
          </View>
        </View>

        <View className="f-both bg-primary">
          <Text className="boldFont title white bold m10">
            {this.state.projectName}
          </Text>
        </View>

        <View className="f-row space-between">
          <View className="f-both p5">
            <View className="ml10 f-row">
              <View className="f-middle">
                <Image
                  className="normal_thumb mr5"
                  source={require("../images/icons/apartment_address.png")}
                />
                <Text className="black medium">
                  {/* {idx(apartment, _ => _.bhk) || 'NA'} */}
                  1BHK
                </Text>
              </View>
              <View className="f-middle ">
                <Text className="black medium ml15">
                  No {"  "} USer 1{"\n"}
                  Area {"  "} 8419118185 {"\n"}Sq.Ft{"\n"}
                </Text>
              </View>
            </View>
          </View>
          <View className="f-both f-row p5 bg-lightBlue">
            <View>
              <View className="f-middle mr20">
                <Text className="white t-center bold medium">
                  Dates
                  {"\n"}
                </Text>
                <Text className="white t-center medium">
                  Completion : 12-18-2019
                </Text>
              </View>
            </View>
          </View>
        </View>

        <View className="divider-black" />

        <View className="f-row">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="p5">
              <Touchable
                style={{
                  backgroundColor: "transparent",
                  height: 50,
                  width: 110,
                  borderWidth: 7,
                  borderColor:
                    this.state.activeFlag === "projects"
                      ? this.state.activeFlagBorderColor
                      : "grey",
                  borderRadius: 70
                }}
                onPress={() => {
                  this.setState({ activeFlag: "projects" });
                }}
              >
                <Text
                  style={{
                    backgroundColor: "transparent",
                    fontFamily: "Roboto-Bold",
                    fontSize: 10,
                    color: "red",
                    textAlign: "center"
                  }}
                >
                  {" "}
                  Project {"\n"} Updates
                </Text>
              </Touchable>
            </View>
            <View className="p5">
              <Touchable
                style={{
                  backgroundColor: "transparent",
                  height: 50,
                  width: 110,
                  borderWidth: 7,
                  borderColor:
                    this.state.activeFlag === "flat"
                      ? this.state.activeFlagBorderColor
                      : "grey",
                  borderRadius: 70
                }}
                onPress={() => {
                  this.setState({
                    activeFlag: "flat"
                  });
                }}
              >
                <Text
                  style={{
                    backgroundColor: "transparent",
                    fontFamily: "Roboto-Bold",
                    fontSize: 15,
                    color: Colors.blue,
                    textAlign: "center"
                  }}
                >
                  {"     "}Flat {"\n"} Updates
                </Text>
              </Touchable>
            </View>
            <View className="p5">
              <Touchable
                style={{
                  backgroundColor: "transparent",
                  height: 50,
                  width: 110,
                  borderWidth: 7,
                  borderColor:
                    this.state.activeFlag === "document"
                      ? this.state.activeFlagBorderColor
                      : "grey",
                  borderRadius: 70
                }}
                onPress={() => {
                  this.setState({
                    activeFlag: "document"
                  });
                }}
              >
                <Text
                  style={{
                    backgroundColor: "transparent",
                    fontFamily: "Roboto-Bold",
                    fontSize: 15,
                    color: Colors.blue,
                    textAlign: "center"
                  }}
                >
                  Documents
                </Text>
              </Touchable>
            </View>
          </ScrollView>
        </View>
        {/* <ScrollView>{this.renderTab()}</ScrollView> */}
      </View>
    );
  }
}

export default PropertyDetails;

// function mapStateToProps(state) {
//   const { user } = state.auth;

//   console.log(state.auth, "authproperty")
//   const apartmentId =  user && user._apartments[0];

//   const { apartments } = state.apartment;
//   const apartment = apartments && apartments.find(a => a._id === apartmentId);

//   const { fetchDetailsRequestStatus, fetchDetailsError, projects } = state.project;
//   const projectId = state.auth.user._projectId;

//   const project =
//     apartment &&
//     projects &&
//     projects.find(p => p._id === apartment._projectId._id);

//   return {
//     apartment,
//     projectId,
//     project,
//     projects,
//     fetchDetailsRequestStatus,
//     fetchDetailsError,
//     user,
//   };
// }

// export default connect(mapStateToProps, { ...ProjectActions })(PropertyDetails);
