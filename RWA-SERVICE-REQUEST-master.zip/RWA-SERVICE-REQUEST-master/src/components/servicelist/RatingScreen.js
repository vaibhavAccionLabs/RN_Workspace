import React from "react";
import { Field, reduxForm } from "redux-form";
import {
  View,
  FormInput,
  Text,
  RatingInput,
  Touchable,
  Spinner,
  Colors,
  LinearGradient
} from "../common";

class RatingScreen extends React.PureComponent {
  render() {
    const { updateServiceRequestStatus } = this.props;
    return (
      <View className="screen">
        <LinearGradient>
          <View className="flex f-center f-middle">
            <View className="expand m15">
              <View className="m15">
                <Field component={RatingInput} name="ratings" />
                <Text className="mb15 t-center">Rate Your Service</Text>
              </View>
              <Field
                component={FormInput}
                placeholder="Enter a Comment"
                name="feedBack"
              />
              <Touchable
                className="btn-primary m15"
                onPress={this.props.handleSubmit}
              >
                {updateServiceRequestStatus === "REQUESTING" ? (
                  <Spinner color={Colors.white} />
                ) : (
                  <Text className="complementary">Close</Text>
                )}
              </Touchable>
            </View>
          </View>
        </LinearGradient>
      </View>
    );
  }
}

export default reduxForm({
  form: "RatingForm"
})(RatingScreen);
