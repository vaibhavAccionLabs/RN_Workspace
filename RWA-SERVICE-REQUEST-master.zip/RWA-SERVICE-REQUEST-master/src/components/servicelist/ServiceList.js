import React from "react";
import { connect } from "react-redux";
import { View, FlatList, Spinner, Header, Touchable, Text } from "../common";
import { ServiceActions } from "../../actions";
import ServiceListCard from "./ServiceListCard";

class ServiceList extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      statusCount: 0
    };
  }
  componentDidMount() {
    //this.props.refreshServiceLists();
  }
  onRefresh = () => {
    //this.props.refreshServiceLists();
  };
  onEndReached = () => {
    //this.props.loadMoreService({ offset: this.props.services.length });
  };
  gotoServiceDetails = id => {
    this.props.navigation.navigate("Service Detail", { id });
  };
  gotoCreateService = () => {
    this.props.navigation.navigate("Service Detail", { id: null });
  };

  keyExtractor = service => service._id;
  renderItem = service => (
    <ServiceListCard service={service} viewDetail={this.gotoServiceDetails} />
  );

  render() {
    // const {
    //   services,
    //   refreshRequestStatus,
    //   loadMoreServiceStatus,
    // } = this.props;

    // if (services) {
    //   const totalStatus = [];
    //   services.forEach(s => {
    //     if (s.status == 'NEW' || s.status == 'OPEN') {
    //       totalStatus.push(s.status);
    //     }
    //   });
    //   this.setState({ statusCount: totalStatus.length });
    // }

    let services = [
      { _id: "01", status: "OPEN", requestType: "a1" },
      { _id: "02", status: "OPEN", requestType: "a1oo" }
    ];

    return (
      <View className="screen">
        <Header
          title="Service List"
          back
          navigation={this.props.navigation}
          openRequest={this.gotoCreateService}
        />
        <View className="f-row btn-completed mh15 mb10 mv10">
          <Text className="completed large bold">Service Request</Text>
          <View className="circle ml10 f-both">
            <Text className="medium white bold">
              0
              {/* {services && this.state.statusCount || 0} */}
            </Text>
          </View>
        </View>
        {services && (
          <FlatList
            className="bgWhite"
            data={services}
            keyExtractor={this.keyExtractor}
            renderItem={this.renderItem}
            onRefresh={this.onRefresh}
            refreshing={false}
            onEndReached={this.onEndReached}
          />
        )}
      </View>
    );
  }
}

export default ServiceList;

// function mapStateToProps(state, props) {
//   const {
//     refreshError,
//     refreshRequestStatus,
//     services,
//     loadMoreServiceStatus,
//   } = state.service;
//   return {
//     refreshError,
//     refreshRequestStatus,
//     services,
//     loadMoreServiceStatus,
//   };
// }

// export default connect(mapStateToProps, { ...ServiceActions })(ServiceList);
