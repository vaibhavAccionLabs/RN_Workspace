import React from "react";
import { Text, View, BackgroundImage, Image, Touchable, Icon } from "../common";
import moment from "moment";

class ServiceListCard extends React.PureComponent {
  render() {
    const { service: { item }, viewDetail } = this.props;
    const serviceNumber = "SR-01";
    {
      /* const technicianName =
      `${item._technicianId.name.first} ${item._technicianId.name.last}`; */
    }
    const imageSource = require("../images/icons/electrical.png");

    return (
      <View>
        <Touchable onPress={() => viewDetail(item._id)} className="f-stretch">
          <View>
            <View className="f-row space-between bgLightGrey">
              <View className="f-both f-row p10">
                <View className="flat-list f-center">
                  <Image
                    className="mini_thumb f-middle mt15"
                    source={imageSource}
                    resizeMode="center"
                  />
                </View>
                <View className="ml10 m3">
                  <Text className="black bold t-left">
                    {item.requestType}
                    {"-"}
                    {serviceNumber}
                  </Text>
                </View>
              </View>
              <View className="f-both f-row p10 m3">
                <View className="ml10">
                  <Text className="black bold t-left">01/01/2018</Text>
                  <View className="f-row f-middle">
                    <Text className="black small mr5">{item.status}</Text>
                    {item.status == "NEW" || item.status == "OPEN" ? (
                      <Image
                        className="statusChecker"
                        source={require("../images/icons/Open_New.png")}
                      />
                    ) : item.status == "ASSIGN" ? (
                      <Image
                        className="statusChecker"
                        source={require("../images/icons/Assigned.png")}
                      />
                    ) : item.status == "COMPLETE" ? (
                      <Image
                        className="statusChecker"
                        source={require("../images/icons/Complete.png")}
                      />
                    ) : null}
                  </View>
                </View>
              </View>
            </View>
            <View className="divider-black" />
          </View>
        </Touchable>
      </View>
    );
  }
}

export default ServiceListCard;
