import React from "react";
import { connect } from "react-redux";
import {
  View,
  ScrollView,
  Text,
  BackgroundImage,
  SelectInput,
  Touchable,
  Header,
  MultiImageUpload,
  DateTimeInput,
  RatingInput,
  FormInput,
  Spinner,
  Colors,
  Icon,
  Image,
  Dropdowns
} from "../common";
import { Modal, TextInput } from "react-native";
import Toast from "react-native-root-toast";
import { ServiceActions, ProjectActions } from "../../actions";
import { Field, reduxForm, formValueSelector } from "redux-form";
import idx from "idx";
import moment from "moment";
import RatingScreen from "./RatingScreen";

class ServiceListDetail extends React.PureComponent {
  constructor() {
    super();
    this.state = {
      showRatingModal: false,
      serviceNumber: "",
      category: [ {
          key: 'c1',
          label: 'c1',
          value: 'c1',
        },
        {
          key: 'c2',
          label: 'c2',
          value: 'c2',
        },
        {
          key: 'c3',
          label: 'c3',
          value: 'c3',
        } ]
    };
  }

  // componentDidMount() {
  //   if (idx(this, _ => _.props.service._projectId._id)) {
  //     this.props.fetchProjectDetails({
  //       projectId: this.props.service._projectId._id,
  //     });
  //   }
  //   this.props.fetchServiceCategories();
  // }

  // componentWillReceiveProps(nextProps) {
  //   const serviceId = this.props.navigation.state.params.id;
  //   if (
  //     nextProps.updateServiceRequestStatus &&
  //     nextProps.updateServiceRequestStatus === 'SUCCESS'
  //   ) {
  //     let successMsg = 'Request Opened!';
  //     if (serviceId) {
  //       successMsg = 'Request Updated!';
  //     }
  //     Toast.show(successMsg, {
  //       duration: Toast.durations.LONG,
  //       position: Toast.positions.BOTTOM,
  //     });
  //     this.props.navigation.goBack();
  //   }
  //   if (
  //     nextProps.updateServiceRequestStatus !== null &&
  //     nextProps.updateServiceRequestStatus === 'FAILED'
  //   ) {
  //     Toast.show(nextProps.updateServiceError, {
  //       duration: Toast.durations.LONG,
  //       position: Toast.positions.BOTTOM,
  //     });
  //   }
  //   if (
  //     nextProps.createServiceRequestStatus !== null &&
  //     nextProps.createServiceRequestStatus === 'FAILED'
  //   ) {
  //     Toast.show(nextProps.createServiceError, {
  //       duration: Toast.durations.LONG,
  //       position: Toast.positions.BOTTOM,
  //     });
  //   }
  // }

  toggleRatingModal = () =>
    this.setState({ showRatingModal: !this.state.showRatingModal });

  // onSubmit = values => {
  //   if (this.props.error) {
  //     Toast.show(this.props.error, {
  //       duration: Toast.durations.LONG,
  //       position: Toast.positions.BOTTOM,
  //     });
  //   }
  //   let date = moment(values.serviceDate).format('DD/MM/YYYY');
  //           console.log(date, ' date');

  //   let startTime = '';
  //   if (values.serviceTime) {
  //     startTime = values.serviceTime.split('-')[0].toString();
  //     console.log(startTime)
  //     if (startTime >= '4 PM' || startTime >= '5 PM') {
  //       console.log('inside' , startTime)
  //       Toast.show(
  //         'Information: Dear Customer, the assignment of technician is based on availability and we assure you that we will have a technician assigned at the earliest. \n Thank you,\n Team Puravankara',
  //         {
  //           duration: Toast.durations.LONG,
  //           position: Toast.positions.TOP,
  //         },
  //       );
  //       startTime = '';
  //       let date =  moment(values.serviceDate).format('DD/MM/YYYY');
  //       date = moment().add(1, 'day').format('DD/MM/YYYY');
  //       console.log(date, 'after date');
  //     }
  //   } else {
  //     startTime = '';
  //   }
  //   const serviceId = this.props.navigation.state.params.id;
  //   let imageUrls = [];
  //   if (values.technicianImages) {
  //     imageUrls = [...values.technicianImages];
  //   }
  //   if (values.customerImages) {
  //     imageUrls = [...imageUrls, ...values.customerImages];
  //   }
  //   const service = {
  //     ...values,
  //     serviceDateTime: moment(
  //       `${date} ${startTime}`,
  //       'DD/MM/YYYY h a',
  //     ).format(),
  //     imageUrls,
  //   };
  //   if (this.props.currentStatus === 'COMPLETE') {
  //     this.toggleRatingModal();
  //   } else if (!serviceId) {
  //     this.props.createService({ service });
  //     if (service) {
  //       Toast.show("Service Request created successfully", {
  //         duration: Toast.durations.LONG,
  //         position: Toast.positions.BOTTOM,
  //       });
  //     }
  //   } else {
  //     console.log(service, 'servicebody')
  //     this.props.updateService({ service });
  //   }
  // };

  getNextStatus = () => {
    const { currentStatus } = this.props;
    let nextStatus = "UPDATE";

    if (!currentStatus) {
      nextStatus = "OPEN";
    }
    if (currentStatus === "COMPLETE") {
      nextStatus = "CLOSE";
    }
    if (currentStatus === "CLOSED") {
      nextStatus = "DONE";
    }
    return nextStatus;
  };

  goBack = () => this.props.navigation.goBack();

  isReadOnly = () => {
    const { currentStatus } = this.props;
    return currentStatus === "COMPLETE" || currentStatus === "CLOSED";
  };

  resetReferenceNumber = () => {
    this.props.change("referenceServiceNumber", null);
  };

  render() {
    // const {
    //   apartment,
    //   organisationId,
    //   updateServiceRequestStatus,
    //   createServiceRequestStatus,
    //   refNumberOptions,
    //   service,
    // } = this.props;

    console.log("aaaaa");

    // let { serviceCategories, requestTypeOptions } = this.props;
    // let locationOptions = idx(apartment, _ => _.rooms) || [];
    // locationOptions = locationOptions.map(location => ({
    //   key: location,
    //   label: location,
    //   value: location,
    // }));
    // serviceCategories = serviceCategories.map(sc => ({
    //   key: sc.category,
    //   label: sc.category,
    // }));
    // requestTypeOptions = requestTypeOptions.map(rt => ({ key: rt, label: rt }));
    // idx(service && service, _ => _.serviceId);
    // if (idx(service, _ => _.serviceId) !== '') {
    //   this.setState({ serviceNumber: '' });
    // } else {
    //   const serviceNum = idx(service, _ => _.serviceNumber).split('/')[1];
    //   this.setState({ serviceNumber: serviceNum });
    // }

    return (
      <View className="screen_transparent">
        <Header
          title="Service Details"
          back
          navigation={this.props.navigation}
        />
        <ScrollView className="flex">
          <View className="f-row space-between bgWhite">
            <View className="f-both f-row p5">
              <View className="ml10">
                <View className="f-row f-middle ">
                  <Image
                    className="normal_thumb mr5"
                    source={require("../images/icons/apartment_address.png")}
                  />
                  <Text className="black medium mr5 mt15">
                    No:aaaa
                    {", "}
                    qqqqq
                  </Text>
                </View>
              </View>
            </View>
            <View className="f-both f-row p5">
              <View className="ml10">
                <View className="f-row f-middle ">
                  <Text className="black medium mr10 mt20">1 bhk</Text>
                </View>
              </View>
            </View>
          </View>
          <View className="divider-black" />

          <View>
            <View className="mt10 f-row ml10">
              <View className="w-2-6">
                <Field
                  component={Dropdowns}
                  name="category"
                  data={this.state.category}
                  light
                  label="category"
                  placeholder="Select category"
                />
              </View>
              <View className="w-2-6">
                <Field
                  component={Dropdowns}
                  name="location"
                  data={this.state.category}
                  light
                  label="location"
                  placeholder="Select location"
                />
              </View>
            </View>
            <View className="mt10 f-row ml10">
              <View className="w-2-6">
                <Field
                  component={Dropdowns}
                  name="requestType"
                  data={this.state.category}
                  light
                  label="requestType"
                  placeholder="Select Req Type"
                />
              </View>
              <View className="w-2-6">
                <Field
                  component={Dropdowns}
                  name="referenceServiceNumber"
                  data={this.state.category}
                  light
                  label="referenceServiceNumber"
                  placeholder="Select Req Number"
                />
              </View>
            </View>
            {/* <Text className="text mr20 t-right blue bold">
              {this.state.serviceNumber}
            </Text> */}

            <View>
              <View className="flex mh15 mv10 space-between">
                <Text className="bold">CUSTOMER PHOTOS</Text>
                <Field
                  component={MultiImageUpload}
                  name="customerImages"
                  numOfFiles={4}
                  organisationId={"5cb6d00dfb6fc041ab927d96"}
                  readOnly={this.isReadOnly()}
                />
              </View>
            </View>

            {/* {idx(service, _ => _.status) === 'ASSIGN' && (
              <View>
                <View className="flex mh15 mv10 space-between">
                  <Text className="bold">TECHNICIAN PHOTOS</Text>
                  <Field
                    component={MultiImageUpload}
                    name="technicianImages"
                    numOfFiles={4}
                    organisationId={'5cb6d00dfb6fc041ab927d96'}
                    readOnly
                  />
                </View>
              </View>
            )} */}

            {/* {idx(service, _ => _.status) === 'CLOSED' && (
              <View>
                <Text className="bold mh15 pv10">Ratings</Text>
                <View className="mh15">
                  <Field
                    component={RatingInput}
                    name="ratings"
                    placeholder='rating'
                    readOnly
                  />
                </View>
                <Text className="bold mh15 pv10">Feedback</Text>
                <View className="mh15">
                  <Field
                    component={FormInput}
                    placeholder='No Feedback'
                    name="feedBack"
                    readOnly
                  />
                </View>
              </View>
            )} */}
          </View>
        </ScrollView>
        <View>
          {/* {idx(service, _ => _.status) === 'ASSIGN' && (
            <View className="f-row bgWhite mh15 ">
              <View className="f-both f-row">
                <View className="ml10">
                  <View className="f-row mt5">
                    <Image
                      className="medium_thumb mr5 mt5"
                      source={require('../images/icons/Technician.png')}
                    />
                    <View className="marginTop10">
                      <TextInput
                        style={{ color: 'black', fontWeight: 'bold' }}
                        value={'Technician Name'}
                        autoCapitalize="none"
                        underlineColorAndroid="transparent"
                        editable={false}
                      />
                      <View className="marginTop20">
                        <TextInput
                          style={{ color: 'black', fontWeight: 'bold' }}
                          value={'Technician Phone'}
                          autoCapitalize="none"
                          underlineColorAndroid="transparent"
                          editable={false}
                        />
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          )} */}
          <Touchable onPress={() => {}} className="btn-primary rounded_15 m15">
            <Text className="white large bold">Ticket</Text>
          </Touchable>
        </View>
        {/* <Modal
          animationType="slide"
          transparent={false}
          visible={this.state.showRatingModal}
          onRequestClose={() => {}}
        >
          <RatingScreen
            onSubmit={this.submitRatings}
            updateServiceRequestStatus={updateServiceRequestStatus}
          />
          <Touchable className="topRight" onPress={this.toggleRatingModal}>
            <Icon name="close" size={30} color="black" />
          </Touchable>
        </Modal> */}
      </View>
    );
  }
}

// function validate(values) {
//   const errors = {};
//   if (values.customerImages === 'Uploading') {
//     errors._error = 'Please wait for images to upload';
//   }
//   return errors;
// }

ServiceListDetail = reduxForm({
  form: "ServiceRequestForm"
})(ServiceListDetail);

const selector = formValueSelector("ServiceRequestForm");

// function mapStateToProps(state, ownProps) {
//   const { user } = state.auth;
//   const apartmentId = user._apartments[0];

//   const { apartments } = state.apartment;
//   const apartment = apartments && apartments.find(a => a._id === apartmentId);

//   const { services } = state.service;
//   const serviceId = ownProps.navigation.state.params.id;
//   const service = services && services.find(s => s._id === serviceId);
//   let initialValues = {
//     _organisationId: idx(user, _=> _._organisationId) || null,
//     _projectId: idx(apartment, _ => _._projectId._id) || null,
//     _customerId: user._id,
//     _apartmentId: idx(apartment, _ => _._id) || idx(apartment, _ => _.__apartmentId._id) || null,
//     status: 'NEW',
//   };
//   if (service) {
//     initialValues = { ...service };
//     const serviceDateTime = service.serviceDateTime || new Date();
//     initialValues.serviceDate = serviceDateTime || serviceDate;
//     initialValues.serviceTime = moment(serviceDateTime).format('hh:mm a');
//     initialValues.customerImages = service.imageUrls.filter(image => image.type === 'FIX');
//     initialValues.technicianImages = service.imageUrls.filter(image => image.type === 'ISSUE');
//   }

//   const { serviceCategories } = state.service;
//   let category = selector(state, 'category');
//   category = serviceCategories.find(sc => sc.category === category);
//   const requestTypeOptions = idx(category, _ => _.subCategories) || [];
//   const refNumberOptions =
//     services &&
//     services
//       .filter(s => s.category === idx(category, _ => _.category))
//       .map(s => ({ key: s.serviceNumber, label: s.serviceNumber }));
//   return {
//     currentStatus: idx(service, _ => _.status) || null,
//     organisationId: user._organisationId,
//     updateServiceRequestStatus: state.service.updateServiceRequestStatus,
//     createServiceRequestStatus : state.service.createServiceRequestStatus,
//     updateServiceError: state.service.updateServiceError,
//     createServiceError : state.service.createServiceError,
//     refNumberOptions,
//     apartment,
//     service,
//     initialValues,
//     serviceCategories,
//     requestTypeOptions,
//   };
// }

// export default connect(mapStateToProps, {
//   ...ServiceActions,
//   ...ProjectActions,
// })(ServiceListDetail);

export default ServiceListDetail;
