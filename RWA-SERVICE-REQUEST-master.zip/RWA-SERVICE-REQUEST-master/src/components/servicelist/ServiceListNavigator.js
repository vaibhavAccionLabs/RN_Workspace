// import { StackNavigator } from 'react-navigation';
// import ServiceList from './ServiceList';
// import ServiceListDetail from './ServiceListDetail';

// const ServiceListNavigator = StackNavigator(
//   {
//     'Service List': {
//       screen: ServiceList,
//     },
//     'Service Detail': {
//       screen: ServiceListDetail,
//     },
//   },
//   {
//     headerMode: 'none',
//   },
// );

// export default ServiceListNavigator;
