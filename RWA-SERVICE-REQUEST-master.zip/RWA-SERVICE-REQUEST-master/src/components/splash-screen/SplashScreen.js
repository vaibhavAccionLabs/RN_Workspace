import React from "react";
import { connect } from "react-redux";
import Splash from "./Splash";

class SplashScreen extends React.PureComponent {
  componentDidMount() {
    let routeName = "Login";
    // if (this.props.isOTPVerified) {
    //   routeName = 'Update Password';
    // }
    // if (this.props.isPasswordUpdated) {
    //   routeName = 'Login';
    // }
    if (this.props.isAuthorizedUser) {
      routeName = "Dashboard";
    }
    this.props.navigation.dispatch({
      type: "Navigation/RESET",
      index: 0,
      actions: [{ type: "Navigation/NAVIGATE", routeName }]
    });
  }

  render() {
    return <Splash />;
  }
}

function mapStateToProps(state) {
  const { isAuthorizedUser } = state.auth;
  //const { isOTPVerified, isPasswordUpdated } = state.otp;
  return {
    isAuthorizedUser
    //isOTPVerified,
    //isPasswordUpdated,
  };
}

export default connect(mapStateToProps, {})(SplashScreen);
