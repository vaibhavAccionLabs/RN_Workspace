import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import { AuthActions } from "../../actions";
import idx from "idx";
import UpdatePasswordForm from "./UpdatePasswordForm";

class UpdatePassword extends React.PureComponent {
  componentWillReceiveProps(nextProps) {
    if (!this.props.isAuthorizedUser && nextProps.isAuthorizedUser) {
      this.props.navigation.dispatch({
        type: "Navigation/RESET",
        index: 0,
        actions: [{ type: "Navigation/NAVIGATE", routeName: "Main" }]
      });
    }
  }

  updatePassword = values => {
    this.props.updatePassword(values);
  };

  render() {
    const {
      initialValues,
      updatePasswordError,
      updatePasswordRequestStatus
    } = this.props;
    return (
      <KeyboardAvoidingView>
        <View className="screen">
          <View className="h-2-5">
            <BackgroundImage
              className="flex f-center f-middle"
              source={require("../images/background_images/login_background.png")}
            >
              <Image source={require("../images/logo.png")} className="logo" />
            </BackgroundImage>
          </View>
          <LinearGradient>
            <View className="flex f-center f-middle bg-transparent">
              <View className="expand mh15">
                <UpdatePasswordForm
                  onSubmit={this.updatePassword}
                  submitError={updatePasswordError}
                  status={updatePasswordRequestStatus}
                  initialValues={initialValues}
                />
              </View>
            </View>
          </LinearGradient>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

function mapStateToProps(state) {
  const { updatePasswordError, updatePasswordRequestStatus } = state.otp;
  const email = idx(state, _ => _.auth.user.email);
  return {
    updatePasswordError,
    updatePasswordRequestStatus,
    isAuthorizedUser: state.auth.isAuthorizedUser,
    initialValues: email ? { emailOrPhone: email } : null
  };
}

export default connect(mapStateToProps, { ...AuthActions })(UpdatePassword);
