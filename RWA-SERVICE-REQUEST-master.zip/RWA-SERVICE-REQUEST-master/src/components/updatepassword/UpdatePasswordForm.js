import React from "react";
import { Field, reduxForm } from "redux-form";
import Toast from "react-native-root-toast";
import { View, Touchable, Text, FormInput, Spinner } from "../common";

class UpdatePasswordForm extends React.PureComponent {
  showErrorAlert = () => {
    Toast.show(this.props.error, {
      duration: Toast.durations.LONG,
      position: Toast.positions.BOTTOM
    });
  };

  gotoBack = () => this.props.navigation.navigate("OTP");

  render() {
    return (
      <View className="mh15">
        <Field
          name="emailOrPhone"
          placeholder="Email"
          component={FormInput}
          type="email-address"
          light
          readOnly={this.props.initialValues}
        />
        <Field
          name="newPassword"
          placeholder="New Password"
          component={FormInput}
          type="password"
          light
        />
        <Field
          name="confirmPassword"
          placeholder="Confirm Password"
          component={FormInput}
          type="password"
          light
        />
        {this.props.submitError && (
          <View className="f-center">
            <Text className="error">{this.props.submitError}</Text>
          </View>
        )}
        {!this.props.error ? (
          <View className="f-row f-stretch">
            <Touchable
              onPress={this.props.handleSubmit}
              className="flex btn-complementary rounded m15 expand"
            >
              {this.props.status === "REQUESTING" ? (
                <Spinner />
              ) : (
                <Text className="primary">Set Password</Text>
              )}
            </Touchable>
          </View>
        ) : (
          <Touchable
            onPress={this.showErrorAlert}
            className="btn-complementary rounded m15 expand"
          >
            <Text className="primary">Set Password</Text>
          </Touchable>
        )}
      </View>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.newPassword) {
    errors._error = errors._error || "Please enter your password";
    errors.password = "Please enter your password";
  }
  if (
    !values.confirmPassword ||
    values.newPassword !== values.confirmPassword
  ) {
    errors._error = errors._error || "Both passwords should match";
    errors.confirmPassword = "Both passwords should match";
  }
  return errors;
}

export default reduxForm({
  form: "UpdatePasswordForm",
  validate
})(UpdatePasswordForm);
