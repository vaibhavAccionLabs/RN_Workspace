import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  Touchable,Dropdowns,
  Text,Header,
  SelectInput,
  Spinner,
  FormInput,Footer,
  Prompt,ScrollView,
  Colors,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import idx from "idx";
import { TextInput } from "react-native";
import { Field, reduxForm, formValueSelector } from "redux-form";
import { VisitorActions } from "../../actions";
import Moment from "moment";

class VisitorDetails extends React.PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      image : "",
      detail : this.props.navigation.state.params
        ? this.props.navigation.state.params.details
        : null
    }
  }

  componentDidMount() {
    this.props.visitorList();
  }

  render() {
    const {
      visitors,
      visitorsList,
      visitorListError,
      visitorListRequestStatus
    } = this.props;
   
    let pastsDetails = []
    visitors && visitors.length > 0 && 
    visitors.forEach(v => {
      if(v._id === this.state.detail._id){
        pastsDetails.push(v)
      }
    })
      
    console.log(this.state.detail ,'VD')
    return (
      <View className="flex_1">
        <View className="screen bgWhite">
          <Header
            back
            navigation={this.props.navigation}
            title="Visitor"
          />
        <ScrollView>
          <View>
            <View>
              <Touchable className="w-2-5" 
                style={{backgroundColor: "transparent", borderBottomWidth: 2, borderBottomColor:'#3CCDFD'}}
                  onPress={() => {}}
                >
                <View className="mr10">
                  <Text className="boldFont black">Details</Text>
                </View>
              </Touchable>
            </View>  
            <View className="h-1-5 f-both mt50">
              <View className="drawer-avatar">
                {!this.state.image ? (
                  <BackgroundImage
                    className="drawer-avatar"
                    source={require("../images/icons/User_Icon.png")}
                    resizeMode="contain"
                  >
                  </BackgroundImage>
                ) : (
                  <Image
                    className="big_thumb"
                    source={require("../images/icons/User_Icon.png")}
                    resizeMode="stretch"
                  />
                )}
              </View>
              <View className="f-column">
                <Text className="t-center bold">{this.state.detail.name && this.state.detail.name.firstName && this.state.detail.name.firstName} {this.state.detail.name && this.state.detail.name.lastName && this.state.detail.name.lastName}</Text>
                <Text className="t-center bold">10th Apr 2019</Text>
              </View>
            </View>
            <View className="mt50">
              <View className="f-row">
                <View className="w-1-0">
                  <Field
                    name={this.state.detail.email}
                    placeholder={this.state.detail.email}
                    component={FormInput}
                    cover
                    editable={false}
                  />
                </View>
              </View>
              <View className="f-row">
                <View className="w-1-2 ">
                  <Field
                    name={this.state.detail.phone}
                    placeholder={this.state.detail.phone}
                    component={FormInput}
                    cover
                    editable={false}
                  />
                </View>
                <View className="w-1-2 ">
                  <Field
                    name={this.state.detail.vehicle}
                    placeholder={this.state.detail.vehicle}
                    component={FormInput}
                    cover
                    editable={false}
                  />
                </View>
              </View> 
              <View className="f-row">
                <View className="w-1-0 ">
                  <Field
                    name="Personal"
                    placeholder="Personal"
                    component={FormInput}
                    cover
                    editable={false}
                  />
                </View>
              </View>  
            </View>
            <View>
              <Touchable className="w-2-5" 
                style={{backgroundColor: "transparent",borderBottomWidth: 2,borderBottomColor:'#3CCDFD'}}
                  onPress={() => {}}
                >
                <View className="mr10">
                  <Text className="boldFont black">Pasts Details</Text>
                </View>
              </Touchable>
            </View>  
            <ScrollView>
              {pastsDetails &&
                pastsDetails.length > 0 &&
                pastsDetails.map((value, i) => (
                <View className="f-row mt10 space-between lightBorder key={i} ">
                  <View className="f-row p5  j-start ">
                    <View className="f-row">
                      <Touchable  >
                        <View >
                          <Image
                            className="mini1_thumb"
                            source={require("../images/icons/User_Icon.png")}
                          />
                        </View>
                      </Touchable>
                    </View>
                    <View className="f-column">
                      <View className="f-row">
                        <Text className="black">{value.name && value.name.firstName && value.name.firstName}</Text>
                      </View>
                      <View>
                        <Text className="black">{value.purpose && value.purpose}</Text>
                      </View>
                    </View>
                  </View>
                  <View className="f-row p5">
                    <View className="f-column">
                      <Text className="black t-right">{Moment(value.createdAt).format("d MMM YYYY")}</Text>
                      <Text className="green t-right">{Moment(value.createdAt).format("hh:mm a")}</Text>
                    </View>
                  </View>
                </View>  
              ))}   
            </ScrollView>
          </View>
          </ScrollView>
        </View>
        <View className="flex01">
          <Footer navigation={this.props.navigation} />
        </View>
      </View>
    );
  }
}

VisitorDetails = reduxForm({
  form: "VisitorDetailsForm",
  destroyOnUnmount: false,
  enableReinitialize: true
})(VisitorDetails);

const selector = formValueSelector("VisitorDetailsForm");

function mapStateToProps(state) {
  const {
    visitors,
    visitorListError,
    visitorListRequestStatus
  } = state.visitor;
  
  console.log(visitors , '11111')
  return {
    visitors,
    visitorListError,
    visitorListRequestStatus
  };
}

export default connect(mapStateToProps, { ...VisitorActions })(VisitorDetails);
  