import React from "react";
import { connect } from "react-redux";
import {
  View,
  BackgroundImage,
  Image,
  Touchable,Dropdowns,
  Text,Header,
  SelectInput,
  Spinner,
  FormInput,Footer,
  Prompt,ScrollView,
  Colors,
  KeyboardAvoidingView,
  LinearGradient
} from "../common";
import idx from "idx";
import { Field, reduxForm, formValueSelector } from "redux-form";
import { VisitorActions } from "../../actions";
import Moment from "moment";


class VisitorList extends React.PureComponent {
  constructor(props) {
    super(props);
  }


  componentDidMount() {
    this.props.visitorList();
  }

  gotoVisitorDetails = initialValues => { 
    console.log(initialValues, "details");
    this.props.navigation.navigate("VisitorDetails", {
      details: initialValues
    });
  }

  render() {
      const {
        visitors,
        visitorsList,
        visitorListError,
        visitorListRequestStatus
      } = this.props;

    console.log(visitorsList ,'88888')
    return (
      <View className="flex_1">
        <View className="screen bgWhite">
          <Header
            back
            navigation={this.props.navigation}
            title="Visitors"
          />
          <View>
          <Touchable className="w-2-5" 
            style={{backgroundColor: "transparent",borderBottomWidth: 2,borderBottomColor:'#3CCDFD'}}
              onPress={() => {}}
            >
            <View className="mr10">
              <Text className="boldFont black">User</Text>
            </View>
          </Touchable>
          </View>  
          <ScrollView>
            {visitorsList &&
              visitorsList.length > 0 &&
              visitorsList.map((value, i) => (
              <View className="f-row mt10 space-between lightBorder key={i} ">
                <View className="f-row p5  j-start ">
                  <View className="f-row">
                    <Touchable  onPress={this.gotoVisitorDetails.bind(this, value)}>
                      <View >
                        <Image
                          className="mini1_thumb"
                          source={require("../images/icons/User_Icon.png")}
                        />
                      </View>
                    </Touchable>
                  </View>
                  <View className="f-column">
                    <View className="f-row">
                      <Text className="black">{value.name && value.name.firstName && value.name.firstName}</Text>
                    </View>
                    <View>
                      <Text className="black">{value.purpose && value.purpose}</Text>
                    </View>
                  </View>
                </View>
                <View className="f-row p5">
                  <View className="f-column">
                    <Text className="black t-right">{Moment(value.createdAt).format("d MMM YYYY")}</Text>
                    <Text className="green t-right">{Moment(value.createdAt).format("hh:mm a")}</Text>
                  </View>
                </View>
              </View>  
            ))}   
          </ScrollView>
          {visitorsList.length === 0 && (
            <View className="p15 mt30">
              <Spinner large />
            </View>
          )}
        </View>
        <View className="flex01">
          <Footer navigation={this.props.navigation} />
        </View>
      </View>
    );
  }
}

function mapStateToProps(state) {
  const {
    visitors,
    visitorListError,
    visitorListRequestStatus
  } = state.visitor;
  
  console.log(visitors , '11111')
  let visitorsList = [];
  visitors &&
    visitors.length > 0 &&
    visitors.forEach(v => {
      if (v.type === "Visitor") {
        visitorsList.push(v);
      }
    });

  return {
    visitors,
    visitorsList,
    visitorListError,
    visitorListRequestStatus
  };
}

export default connect(mapStateToProps, { ...VisitorActions })(VisitorList);
