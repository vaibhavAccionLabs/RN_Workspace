import ip from "icepick";
import { ApartmentActions } from "../actions";

const updateApartmentInfo = (allApartments, newApartments) => {
  if (!allApartments) {
    allApartments = ip.freeze([]);
  }
  newApartments.forEach(newApartment => {
    const exists = allApartments.find(
      apartment => apartment._id === newApartment._id
    );
    if (exists) {
      const existingIndex = allApartments.indexOf(exists);
      allApartments = ip.setIn(allApartments, [existingIndex], newApartment);
    } else {
      allApartments = ip.push(allApartments, newApartment);
    }
  });
  return allApartments;
};

const requestStatus = ["REQUESTING", "FAILED", "SUCCESS"];
const initialState = {
  apartments: null,
  getApartmentInfoRequestStatus: null,
  getApartmentInfoError: null
};

export default function(state = initialState, action) {
  switch (action.type) {
    case ApartmentActions.GET_APARTMENT_INFO_REQUEST:
      state = ip.setIn(state, ["getApartmentInfoError"], null);
      return ip.setIn(
        state,
        ["getApartmentInfoRequestStatus"],
        requestStatus[0]
      );

    case ApartmentActions.GET_APARTMENT_INFO_FAILURE:
      state = ip.setIn(state, ["getApartmentInfoError"], action.payload);
      return ip.setIn(
        state,
        ["getApartmentInfoRequestStatus"],
        requestStatus[1]
      );

    case ApartmentActions.GET_APARTMENT_INFO_SUCCESS: {
      const { apartmentInfo } = action.payload;
      state = ip.setIn(
        state,
        ["apartments"],
        updateApartmentInfo(state.apartments, [apartmentInfo])
      );
      return ip.setIn(state, ["verifyOTPRequestStatus"], requestStatus[2]);
    }

    default:
      return state;
  }
}
