import ip from "icepick";
import { EventActions } from "../actions";

const requestStatus = ["REQUESTING", "FAILED", "SUCCESS"];
const initialState = {
  createEventRequestStatus: null,
  createEventError: null,
  updateEventRequestStatus: null,
  updateEventError: null,
  getEventsRequestStatus: null,
  getEventsError: null,
  getSingleEventRequestStatus: null,
  getSingleEventError: null
};

export default function(state = initialState, action) {
  switch (action.type) {

    // create event
    case EventActions.CREATE_EVENT_REQUEST:
      state = ip.setIn(state, ["createEventError"], null);
      return ip.setIn(state, ["createEventRequestStatus"], requestStatus[0]);

    case EventActions.CREATE_EVENT_FAILURE:
      state = ip.setIn(state, ["createEventError"], action.payload);
      return ip.setIn(state, ["createEventRequestStatus"], requestStatus[1]);

    case EventActions.CREATE_EVENT_SUCCESS:
      return ip.setIn(state, ["createEventRequestStatus"], requestStatus[2]);

    // update event  
    case EventActions.UPDATE_EVENT_REQUEST:
      state = ip.setIn(state, ["updateEventError"], null);
      return ip.setIn(state, ["updateEventRequestStatus"], requestStatus[0]);

    case EventActions.UPDATE_EVENT_FAILURE:
      state = ip.setIn(state, ["updateEventError"], action.payload);
      return ip.setIn(state, ["updateEventRequestStatus"], requestStatus[1]);

    case EventActions.UPDATE_EVENT_SUCCESS:
      return ip.setIn(state, ["updateEventRequestStatus"], requestStatus[2]);

    // get event lists
    case EventActions.GET_EVENTS_REQUEST:
      state = ip.setIn(state, ["getEventsError"], null);
      return ip.setIn(state, ["getEventsRequestStatus"], requestStatus[0]);

    case EventActions.GET_EVENTS_FAILURE:
      state = ip.setIn(state, ["getEventsError"], action.payload);
      return ip.setIn(state, ["getEventsRequestStatus"], requestStatus[1]);

    case EventActions.GET_EVENTS_SUCCESS:
      state = ip.setIn(state, ["isPasswordUpdated"], true);
      return ip.setIn(state, ["getEventsRequestStatus"], requestStatus[2]);

    // get single events

    case EventActions.GET_SINGLE_EVENT_REQUEST:
      state = ip.setIn(state, ["getSingleEventError"], null);
      return ip.setIn(state, ["getSingleEventRequestStatus"], requestStatus[0]);

    case EventActions.GET_SINGLE_EVENT_FAILURE:
      state = ip.setIn(state, ["getSingleEventError"], action.payload);
      return ip.setIn(state, ["getSingleEventRequestStatus"], requestStatus[1]);

    case EventActions.GET_SINGLE_EVENT_SUCCESS: {
      return ip.setIn(state, ["getSingleEventRequestStatus"], requestStatus[2]);
    }

    default:
      return state;
  }
}
