import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";
import { AuthActions } from "../actions";
import loginReducer from "./loginReducer";
import authReducer from "./authReducer";
import paymentReducer from "./paymentReducer";
import apartmentReducer from "./apartmentReducer";
import serviceReducer from "./serviceReducer";
import eventReducer from "./eventReducer";
import notificationReducer from "./notificationReducer";
import visitorReducer from "./visitorReducer";

const appReducer = combineReducers({
  form: formReducer,
  login: loginReducer,
  auth: authReducer,
  payment: paymentReducer,
  apartment: apartmentReducer,
  service: serviceReducer,
  event: eventReducer,
  notification: notificationReducer,
  visitor : visitorReducer
});

const rootReducer = (state, action) => {
  if (action.type === AuthActions.LOGOUT) {
    state = { login: state.login };
  }

  return appReducer(state, action);
};

export default rootReducer;
