import ip from "icepick";
import { PaymentActions } from "../actions";

const requestStatus = ["REQUESTING", "FAILED", "SUCCESS"];
const initialState = {
  paymentsList : null,
  createPaymentRequestStatus: null,
  createPaymentError: null,
  getPaymentsListRequestStatus: null,
  getPaymentsListError: null,
};

export default function(state = initialState, action) {
  switch (action.type) {


    // create Payment
    case PaymentActions.CREATE_PAYMENT_REQUEST:
      state = ip.setIn(state, ["createPaymentError"], null);
      return ip.setIn(state, ["createPaymentRequestStatus"], requestStatus[0]);

    case PaymentActions.CREATE_PAYMENT_FAILURE:
      state = ip.setIn(state, ["createPaymentError"], action.payload);
      return ip.setIn(state, ["createPaymentRequestStatus"], requestStatus[1]);

    case PaymentActions.CREATE_PAYMENT_SUCCESS:
      return ip.setIn(state, ["createPaymentRequestStatus"], requestStatus[2]);

    // get Payment lists
    case PaymentActions.GET_PAYMENTS_LIST_REQUEST:
      state = ip.setIn(state, ["getPaymentsListError"], null);
      return ip.setIn(state, ["getPaymentsListRequestStatus"], requestStatus[0]);

    case PaymentActions.GET_PAYMENTS_LIST_FAILURE:
      state = ip.setIn(state, ["getPaymentsListError"], action.payload);
      return ip.setIn(state, ["getPaymentsListRequestStatus"], requestStatus[1]);

    case PaymentActions.GET_PAYMENTS_LIST_SUCCESS:
      const { payments } = action.payload;
      state = ip.setIn(state, ["paymentsList"], payments);
      state = ip.setIn(state, ["getPaymentsListRequestStatus"], requestStatus[2]);
      return state;

    default:
      return state;
  }
}
