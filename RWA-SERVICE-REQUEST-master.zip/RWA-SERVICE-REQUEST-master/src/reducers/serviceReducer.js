import ip from "icepick";
import { ServiceActions } from "../actions";

const updateServiceInfo = (allServices, newServices) => {
  if (!allServices) {
    allServices = ip.freeze([]);
  }
  newServices.forEach(newService => {
    const exists = allServices.find(service => service._id === newService._id);
    if (exists) {
      const existingIndex = allServices.indexOf(exists);
      allServices = ip.setIn(allServices, [existingIndex], newService);
    } else {
      allServices = ip.push(allServices, newService);
    }
  });
  return allServices;
};

const requestStatus = ["REQUESTING", "FAILED", "SUCCESS"];
const initialState = {
  refreshRequestStatus: null,
  refreshError: null,
  services: null,
  updateServiceRequestStatus: null,
  updateServiceError: null,
  serviceCategories: [],
  fetchServiceCategoriesRequestStatus: null,
  fetchServiceCategoriesError: null,
  loadMoreServiceStatus: null,
  loadMoreServiceError: null,
  createServiceRequestStatus: null,
  createServiceError: null
};

export default function(state = initialState, action) {
  switch (action.type) {
    case ServiceActions.REFRESH_SERVICE_LISTS_REQUEST:
      return ip.setIn(state, ["refreshRequestStatus"], requestStatus[0]);

    case ServiceActions.REFRESH_SERVICE_LISTS_FAILURE:
      state = ip.setIn(state, ["refreshError"], action.payload);
      return ip.setIn(state, ["refreshRequestStatus"], requestStatus[1]);

    case ServiceActions.REFRESH_SERVICE_LISTS_SUCCESS: {
      const { services } = action.payload;
      state = ip.setIn(state, ["services"], services);
      state = ip.setIn(state, ["refreshRequestStatus"], requestStatus[2]);
      return state;
    }

    case ServiceActions.LOAD_MORE_SERVICE_REQUEST:
      return ip.setIn(state, ["loadMoreServiceStatus"], requestStatus[0]);

    case ServiceActions.LOAD_MORE_SERVICE_FAILURE:
      state = ip.setIn(state, ["loadMoreServiceError"], action.payload);
      return ip.setIn(state, ["loadMoreServiceStatus"], requestStatus[1]);

    case ServiceActions.LOAD_MORE_SERVICE_SUCCESS: {
      const { services } = action.payload;
      state = ip.setIn(
        state,
        ["services"],
        updateServiceInfo(state.services, services)
      );
      state = ip.setIn(state, ["loadMoreServiceStatus"], requestStatus[2]);
      return state;
    }

    case ServiceActions.UPDATE_SERVICE_REQUEST:
      return ip.setIn(state, ["updateServiceRequestStatus"], requestStatus[0]);

    case ServiceActions.UPDATE_SERVICE_FAILURE:
      state = ip.setIn(state, ["updateServiceError"], action.payload);
      return ip.setIn(state, ["updateServiceRequestStatus"], requestStatus[1]);

    case ServiceActions.UPDATE_SERVICE_SUCCESS: {
      const { service } = action.payload;
      state = ip.setIn(
        state,
        ["services"],
        updateServiceInfo(state.services, [service])
      );
      state = ip.setIn(state, ["updateServiceRequestStatus"], requestStatus[2]);
      return state;
    }

    case ServiceActions.CREATE_SERVICE_REQUEST:
      return ip.setIn(state, ["createServiceRequestStatus"], requestStatus[0]);

    case ServiceActions.CREATE_SERVICE_FAILURE:
      state = ip.setIn(state, ["createServiceError"], action.payload);
      return ip.setIn(state, ["createServiceRequestStatus"], requestStatus[1]);

    case ServiceActions.CREATE_SERVICE_SUCCESS: {
      const { service } = action.payload;
      state = ip.setIn(
        state,
        ["services"],
        ip.freeze([service, ...state.services])
      );
      state = ip.setIn(state, ["createServiceRequestStatus"], requestStatus[2]);
      return state;
    }

    case ServiceActions.FETCH_SERVICE_CATEGORIES_REQUEST:
      return ip.setIn(
        state,
        ["fetchServiceCategoriesRequestStatus"],
        requestStatus[0]
      );

    case ServiceActions.FETCH_SERVICE_CATEGORIES_FAILURE:
      state = ip.setIn(state, ["fetchServiceCategoriesError"], action.payload);
      return ip.setIn(
        state,
        ["fetchServiceCategoriesRequestStatus"],
        requestStatus[1]
      );

    case ServiceActions.FETCH_SERVICE_CATEGORIES_SUCCESS: {
      const { serviceCategories } = action.payload;
      state = ip.setIn(
        state,
        ["serviceCategories"],
        ip.freeze(serviceCategories)
      );
      state = ip.setIn(
        state,
        ["fetchServiceCategoriesRequestStatus"],
        requestStatus[2]
      );
      return state;
    }

    default:
      return ip.setIn(state, ["refreshError"], null);
  }
}
