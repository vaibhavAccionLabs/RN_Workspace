import ip from "icepick";
import { VisitorActions } from "../actions";

const requestStatus = ["REQUESTING", "FAILED", "SUCCESS"];
const initialState = {
  getVisitorsRequestStatus: null,
  getVisitorsError: null,
  visitors : null
};

export default function(state = initialState, action) {
  switch (action.type) {

    // // create Visitor
    // case VisitorActions.VISITOR_LIST_REQUEST:
    //   state = ip.setIn(state, ["createVisitorError"], null);
    //   return ip.setIn(state, ["createVisitorRequestStatus"], requestStatus[0]);

    // case VisitorActions.VISITOR_LIST_FAILURE:
    //   state = ip.setIn(state, ["createVisitorError"], action.payload);
    //   return ip.setIn(state, ["createVisitorRequestStatus"], requestStatus[1]);

    // case VisitorActions.VISITOR_LIST_SUCCESS:
    //   return ip.setIn(state, ["createVisitorRequestStatus"], requestStatus[2]);

    // get Visitor lists
    case VisitorActions.VISITOR_LIST_REQUEST:
      state = ip.setIn(state, ["getVisitorsError"], null);
      return ip.setIn(state, ["getVisitorsRequestStatus"], requestStatus[0]);

    case VisitorActions.VISITOR_LIST_FAILURE:
      state = ip.setIn(state, ["getVisitorsError"], action.payload);
      return ip.setIn(state, ["getVisitorsRequestStatus"], requestStatus[1]);

    case VisitorActions.VISITOR_LIST_SUCCESS: 
      const { visitorLists } = action.payload;
      state = ip.setIn(state, ["visitors"], visitorLists);
      state = ip.setIn(state, ["getVisitorsRequestStatus"], requestStatus[2]);
      return state;

    default:
      return state;
  }
}
