import { put, call, all, fork, takeLatest, select } from "redux-saga/effects";
import { ApartmentActions, ProjectActions } from "../actions";
import { GET } from "../api";
import idx from "idx";

const getUser = state => state.auth.user;

function* getApartmentInfo() {
  yield put(ApartmentActions.getApartmentInfoRequest());
  try {
    const user = yield select(getUser);
    const apartmentId = user._apartments[0];
    const apartmentUrl = `apartments/${apartmentId}`;
    const { response } = yield call(GET, apartmentUrl);
    const apartmentInfo = idx(response, _ => _.data.data);
    const projectId = idx(apartmentInfo, _ => _._projectId._id);
    if (projectId) {
      yield put(ProjectActions.fetchProjectDetails({ projectId }));
    }
    yield put(ApartmentActions.getApartmentInfoSuccess({ apartmentInfo }));
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ApartmentActions.getApartmentInfoFailure(msgError));
  }
}

export default function* authSagas() {
  yield all([
    fork(takeLatest, ApartmentActions.GET_APARTMENT_INFO, getApartmentInfo)
  ]);
}
