import { put, call, all, fork, takeLatest } from "redux-saga/effects";
import { EventActions } from "../actions";
import { GET, PUT, POST } from "../api";
import idx from "idx";

function* getEvents() {
  yield put(EventActions.getEventsRequest());
  try {
    const EventsUrl = "/Events";
    const { response } = yield call(GET, EventsUrl);
    yield put(
      EventActions.getEventsSuccess({
        Events: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(EventActions.getEventsFailure(msgError));
  }
}

function* updateEvent(action) {
  yield put(EventActions.updateEventRequest());
  try {
    const updateEventUrl = "/Events";
    const { response } = yield call(PUT, updateEventUrl , action.payload);
    yield put(
      EventActions.updateEventSuccess({
        events: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(EventActions.updateEventFailure(msgError));
  }
}

function* createEvent(action) {
  yield put(EventActions.getEventsRequest());
  try {
    const EventsUrl = "/Events";
    const { response } = yield call(POST, EventsUrl , action.payload);
    yield put(
      EventActions.getEventsSuccess({
        Events: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(EventActions.getEventsFailure(msgError));
  }
}

function* getSingleEvent(action) {
  yield put(EventActions.getSingleEventtRequest());
  try {
    const getSingleEventUrl = "/event/id";
    const { response } = yield call(GET, getSingleEventUrl);
    yield put(
      EventActions.getSingleEventSuccess({
        event: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(EventActions.getSingleEventFailure(msgError));
  }
}

export default function* eventSagas() {
  yield all([
    fork(takeLatest, EventActions.CREATE_EVENT, createEvent)
  ]);
  yield all([
    fork(takeLatest, EventActions.UPDATE_EVENT, updateEvent)
  ]);
  yield all([
    fork(takeLatest, EventActions.GET_EVENTS, getEvents)
  ]);
  yield all([
    fork(takeLatest, EventActions.GET_SINGLE_EVENT, getSingleEvent)
  ]);
}
