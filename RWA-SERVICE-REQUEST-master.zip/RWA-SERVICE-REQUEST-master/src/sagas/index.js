import { fork, all } from "redux-saga/effects";
import authSagas from "./authSagas";
import otpSagas from "./otpSagas";
import apartmentSagas from "./apartmentSagas";
import serviceSagas from "./serviceSagas";
import paymentSagas from "./paymentSagas";
import eventSagas from "./eventSagas";
import visitorSagas from "./visitorSagas";
import notificationSagas from "./notificationSagas";

export default function* sagas() {
  yield all([fork(authSagas)]);
  yield all([fork(otpSagas)]);
  yield all([fork(apartmentSagas)]);
  yield all([fork(serviceSagas)]);
  yield all([fork(paymentSagas)]);
  yield all([fork(notificationSagas)]);
  yield all([fork(eventSagas)]);
  yield all([fork(visitorSagas)]);
}
