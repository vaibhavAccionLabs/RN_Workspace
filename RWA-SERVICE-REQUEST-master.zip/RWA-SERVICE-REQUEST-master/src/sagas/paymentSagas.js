import { put, call, all, fork, takeLatest } from "redux-saga/effects";
import { PaymentActions } from "../actions";
import { GET, POST } from "../api";
import idx from "idx";

function* getPaymentsList() {
  yield put(PaymentActions.getPaymentsListRequest());
  try {
    const PaymentsUrl = "/payments";
    const { response } = yield call(GET, PaymentsUrl);
    yield put(
      PaymentActions.getPaymentsListSuccess({
        payments: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(PaymentActions.getPaymentsListFailure(msgError));
  }
}

function* createPayment(action) {
  yield put(PaymentActions.createPaymentRequest());
  try {
    const { payment } = action.payload;
    const createPaymentUrl = "/payment";
    const { response } = yield call(POST, createPaymentUrl ,payment);
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(PaymentActions.createPaymentFailure(msgError));
  }
}

export default function* paymentSagas() {
  yield all([
    fork(takeLatest, PaymentActions.GET_PAYMENTS_LIST, getPaymentsList)
  ]);
  yield all([
    fork(takeLatest, PaymentActions.CREATE_PAYMENT, createPayment)
  ]);
}
