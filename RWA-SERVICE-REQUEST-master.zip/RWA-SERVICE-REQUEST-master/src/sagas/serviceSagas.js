import { put, call, all, fork, takeLatest, select } from "redux-saga/effects";
import { ServiceActions } from "../actions";
import { GET, PUT, POST } from "../api";
import idx from "idx";

const getUser = state => state.auth.user;
const getApartments = state => state.apartment.apartments;
const getProjects = state => state.project.projects;
const limit = 20;

function* refreshServiceLists() {
  yield put(ServiceActions.refreshServiceListsRequest());
  try {
    const user = yield select(getUser);
    const apartmentId = user._apartments[0];
    const apartments = yield select(getApartments);
    const apartment = apartments && apartments.find(a => a._id === apartmentId);
    const projects = yield select(getProjects);
    const project =
      projects && projects.find(p => p._id === apartment._projectId._id);
    let filter = "";
    if (apartment) {
      filter += `filter[_apartmentId]=${apartment._id}`;
    }
    if (project) {
      filter += `&filter[_projectId]=${project._id}`;
    }
    const refreshServiceListsURL = `/services?${filter}&limit=${
      limit
    }&with[user]=name,phone,email,displayName,profileImageUrl,username`;
    const { response } = yield call(GET, refreshServiceListsURL);
    yield put(
      ServiceActions.refreshServiceListsSuccess({
        services: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ServiceActions.refreshServiceListsFailure(msgError));
  }
}

function* loadMoreService(action) {
  const { offset } = action.payload;
  yield put(ServiceActions.loadMoreServiceRequest());
  try {
    const user = yield select(getUser);
    const filter = `filter[_organisationId]=${user._organisationId}`;
    const loadMoreServiceURL = `/services?${filter}&offset=${offset}&limit=${
      limit
    }&with[user]=name,phone,email,displayName,profileImageUrl,username`;
    const { response } = yield call(GET, loadMoreServiceURL);
    yield put(
      ServiceActions.loadMoreServiceSuccess({
        services: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ServiceActions.loadMoreServiceFailure(msgError));
  }
}

function* updateService(action) {
  yield put(ServiceActions.updateServiceRequest());
  try {
    const { service } = action.payload;
    const updateServiceUrl = `/services/${service._id}`;
    const { response } = yield call(PUT, updateServiceUrl, service);
    yield put(
      ServiceActions.updateServiceSuccess({
        service: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ServiceActions.updateServiceFailure(msgError));
  }
}

function* createService(action) {
  yield put(ServiceActions.createServiceRequest());
  try {
    const { service } = action.payload;
    const createServiceUrl = "/services";
    const { response } = yield call(POST, createServiceUrl, service);
    yield put(
      ServiceActions.createServiceSuccess({
        service: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ServiceActions.createServiceFailure(msgError));
  }
}

function* fetchServiceCategories() {
  yield put(ServiceActions.fetchServiceCategoriesRequest());
  try {
    const fetchServiceCategoriesUrl = "/servicecategories";
    const { response } = yield call(GET, fetchServiceCategoriesUrl);
    yield put(
      ServiceActions.fetchServiceCategoriesSuccess({
        serviceCategories: idx(response, _ => _.data.data)
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(ServiceActions.fetchServiceCategoriesFailure(msgError));
  }
}

export default function* authSagas() {
  yield all([
    fork(takeLatest, ServiceActions.LOAD_MORE_SERVICE, loadMoreService)
  ]);
  yield all([
    fork(takeLatest, ServiceActions.REFRESH_SERVICE_LISTS, refreshServiceLists)
  ]);
  yield all([fork(takeLatest, ServiceActions.UPDATE_SERVICE, updateService)]);
  yield all([
    fork(
      takeLatest,
      ServiceActions.FETCH_SERVICE_CATEGORIES,
      fetchServiceCategories
    )
  ]);
  yield all([fork(takeLatest, ServiceActions.CREATE_SERVICE, createService)]);
}
