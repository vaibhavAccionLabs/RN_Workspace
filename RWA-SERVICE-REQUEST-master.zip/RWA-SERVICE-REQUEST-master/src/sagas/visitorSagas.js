import { put, call, all, fork, takeLatest } from "redux-saga/effects";
import { VisitorActions } from "../actions";
import { GET } from "../api";
import idx from "idx";

function* visitorList() {
  yield put(VisitorActions.visitorListRequest());
  try {
    const VisitorsUrl = "/visitor";
    const { response } = yield call(GET, VisitorsUrl);
    yield put(
      VisitorActions.visitorListSuccess({
        visitorLists: response.data
      })
    );
  } catch (error) {
    let msgError = error;
    if (error.message) {
      msgError = error.message;
    }
    yield put(VisitorActions.visitorListFailure(msgError));
  }
}

function* visitorDetails(action) {
  yield put(VisitorActions.visitorDetailsRequest());
  try {
    const { Visitor } = action.payload;
    const visitorDetailsUrl = "/visitor/id";
    const { response } = yield call(GET, visitorDetailsUrl ,Visitor);
  } catch (error) {
    let msgError = error;
    if (error.data) {
      msgError = error.data.error.message;
    }
    yield put(VisitorActions.visitorDetailsFailure(msgError));
  }
}

export default function* visitorSagas() {
  yield all([
    fork(takeLatest, VisitorActions.VISITOR_LIST, visitorList)
  ]);
  yield all([
    fork(takeLatest, VisitorActions.VISITOR_DETAILS, visitorDetails)
  ]);
}
