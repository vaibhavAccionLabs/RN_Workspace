/* local server */
///export const LOCAL_API_URL = "http://10.0.2.2:9999";

/*Production url on aws*/
export const API_BASE_URL = "https://rwaapi.briclay.com";
