export const INCREASE_COUNT = 'increase_count';
export const DECREASE_COUNT = 'decrease_count';
