# Counter example

Sample Application to better understand how react native works with redux

## Run APP

Open `Terminal.app` and navigate to the app directory and paste the below commands:

## For iOS
```
$ npm install
$ react-native run-ios
``` 

## For Android
```
$ npm install
$ react-native run-android
``` 
