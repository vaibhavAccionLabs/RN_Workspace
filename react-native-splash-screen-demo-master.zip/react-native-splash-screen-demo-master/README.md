Code for a tutorial on adding splash screens to your React Native app (tutorial coming soon).

# Installation

- `git clone https://github.com/spencercarli/react-native-splash-screen-demo.git`
- `cd react-native-splash-screen-demo`
- `yarn install` or `npm install`
- `react-native run-ios` or `react-native run-android`
